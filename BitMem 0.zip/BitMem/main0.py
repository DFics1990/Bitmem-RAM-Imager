import os
import subprocess
import threading
import customtkinter as ctk
from tkinter import filedialog, messagebox, StringVar
import hashlib
from datetime import datetime
import time
import psutil
from fpdf import FPDF
from PIL import Image
from customtkinter import CTkImage
from pathlib import Path
import json
from docx import Document
import html
import platform
import logging
import zipfile

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('bitmem.log'),
        logging.StreamHandler()
    ]
)

# Configure appearance
ctk.set_appearance_mode("Dark")
ctk.set_default_color_theme("dark-blue")

# Color Theme
DARK_BACKGROUND = "#1E2A38"
DARK_PRIMARY = "#3498DB"
DARK_SECONDARY = "#2C3E50"
DARK_ACCENT = "#2980B9"
DARK_TEXT = "#ECF0F1"

LIGHT_BACKGROUND = "#FFFFFF"
LIGHT_PRIMARY = "#3498DB"
LIGHT_SECONDARY = "#F4F4F4"
LIGHT_ACCENT = "#2980B9"
LIGHT_TEXT = "#2C3E50"

# Global color variables
BACKGROUND_COLOR = DARK_BACKGROUND
PRIMARY_COLOR = DARK_PRIMARY
SECONDARY_COLOR = DARK_SECONDARY
ACCENT_COLOR = DARK_ACCENT
TEXT_COLOR = DARK_TEXT

# Base directory
BASE_DIR = Path(__file__).parent
ASSETS_DIR = BASE_DIR / "assets"
ICONS_DIR = ASSETS_DIR / "icons"
IMAGES_DIR = ASSETS_DIR / "images"
CONFIG_FILE = BASE_DIR / "bitmem_config.json"
VOLATILITY_PATH = BASE_DIR / "volatility3"

def load_config():
    """Load configuration from file"""
    if CONFIG_FILE.exists():
        try:
            with open(CONFIG_FILE, 'r') as f:
                config = json.load(f)
                if 'appearance_mode' in config:
                    ctk.set_appearance_mode(config['appearance_mode'])
                    if config['appearance_mode'] == "Light":
                        global BACKGROUND_COLOR, PRIMARY_COLOR, SECONDARY_COLOR, ACCENT_COLOR, TEXT_COLOR
                        BACKGROUND_COLOR = LIGHT_BACKGROUND
                        PRIMARY_COLOR = LIGHT_PRIMARY
                        SECONDARY_COLOR = LIGHT_SECONDARY
                        ACCENT_COLOR = LIGHT_ACCENT
                        TEXT_COLOR = LIGHT_TEXT
                return config
        except Exception as e:
            logging.error(f"Error loading config: {e}")
    return {}

def save_config(config):
    """Save configuration to file"""
    try:
        with open(CONFIG_FILE, 'w') as f:
            json.dump(config, f, indent=4)
    except Exception as e:
        logging.error(f"Error saving config: {e}")

def show_error(msg):
    """Show error message"""
    logging.error(msg)
    messagebox.showerror("Error", msg)

def show_info(msg):
    """Show info message"""
    logging.info(msg)
    messagebox.showinfo("Information", msg)

def calculate_hash(file_path, algorithm="sha256"):
    """Calculate file hash"""
    hash_func = hashlib.new(algorithm)
    with open(file_path, "rb") as f:
        for chunk in iter(lambda: f.read(4096), b""):
            hash_func.update(chunk)
    return hash_func.hexdigest()

def compress_file(file_path):
    """Compress file using zipfile"""
    try:
        zip_filename = os.path.basename(file_path) + ".zip"
        zip_path = os.path.join(os.path.dirname(file_path), zip_filename)
        
        with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
            zipf.write(file_path, os.path.basename(file_path))
        
        logging.info(f"File compressed to {zip_path}")
        return zip_path
    except Exception as e:
        logging.error(f"Compression failed: {e}")
        return None

def analyze_with_volatility(image_path, output_dir):
    """Analyze memory dump with Volatility"""
    try:
        volatility_exe = None
        if (VOLATILITY_PATH / "vol.exe").exists():
            volatility_exe = str(VOLATILITY_PATH / "vol.exe")
        elif (VOLATILITY_PATH / "vol.py").exists():
            volatility_exe = f"python {str(VOLATILITY_PATH / 'vol.py')}"
        else:
            show_error(f"Volatility not found at: {VOLATILITY_PATH}")
            return None
        
        output_file = os.path.join(output_dir, f"volatility_analysis_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt")
        
        commands = [
            "windows.info.Info",
            "windows.pslist.PsList",
            "windows.pstree.PsTree",
            "windows.netscan.NetScan"
        ]
        
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write(f"Volatility Analysis Report - {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
            f.write(f"Memory Image: {image_path}\n")
            f.write("="*80 + "\n\n")
            
            for cmd in commands:
                try:
                    f.write(f"\n=== {cmd} ===\n")
                    if volatility_exe.endswith(".exe"):
                        result = subprocess.run(
                            [volatility_exe, '-f', image_path, cmd],
                            capture_output=True, text=True, check=True,
                            encoding='utf-8', errors='replace'
                        )
                    else:
                        result = subprocess.run(
                            volatility_exe.split() + ['-f', image_path, cmd],
                            capture_output=True, text=True, check=True,
                            encoding='utf-8', errors='replace'
                        )
                    f.write(result.stdout)
                    
                    if result.stderr:
                        f.write(f"\nErrors:\n{result.stderr}\n")
                except subprocess.CalledProcessError as e:
                    f.write(f"Error running {cmd}:\n{e.stderr}\n")
        
        logging.info(f"Volatility analysis saved to {output_file}")
        return output_file
    except Exception as e:
        logging.error(f"Volatility analysis failed: {e}")
        return None

def generate_report(output_file, investigator_name, investigator_id, case_name, case_id, memory_id, hash_value, image_size, elapsed_time, report_format, hash_algorithm):
    """Generate report in selected format"""
    report_file_name = f"Case-{case_name.replace(' ', '_')}_Report.{report_format}"
    report_file = os.path.join(os.path.dirname(output_file), report_file_name)
    
    capture_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    minutes = int(elapsed_time // 60)
    seconds = elapsed_time % 60
    duration_str = f"{minutes} minutes {seconds:.2f} seconds"
    formatted_image_size = "{:,}".format(image_size)
    
    report_data = [
        ("Investigator Name:", investigator_name),
        ("Investigator ID:", investigator_id),
        ("Case Name:", case_name),
        ("Case ID:", case_id),
        ("Memory ID:", memory_id),
        ("Capture Time:", capture_time),
        ("Image Size:", f"{formatted_image_size} bytes ({image_size/1024/1024:,.2f} MB)"),
        ("Hash Algorithm:", hash_algorithm),
        ("Hash Value:", hash_value),
        ("Image Location:", output_file),
        ("Capture Duration:", duration_str)
    ]

    if report_format.lower() == "txt":
        with open(report_file, "w", encoding='utf-8') as f:
            f.write("=== MEMORY CAPTURE REPORT ===\n\n")
            for key, value in report_data:
                f.write(f"{key} {value}\n")
    
    elif report_format.lower() == "pdf":
        pdf = FPDF()
        pdf.add_page()
        pdf.set_font("Arial", size=12)
        pdf.set_font("Arial", 'B', 16)
        pdf.cell(0, 10, "MEMORY CAPTURE REPORT", ln=True, align='C')
        pdf.ln(10)
        pdf.set_font("Arial", size=12)
        
        for key, value in report_data:
            pdf.cell(0, 10, f"{key} {value}", ln=True)
            pdf.ln(5)
        
        pdf.output(report_file)
    
    elif report_format.lower() == "html":
        with open(report_file, "w", encoding='utf-8') as f:
            f.write("<!DOCTYPE html>\n<html>\n<head>\n<title>Memory Capture Report</title>\n")
            f.write("<style>\nbody {font-family: Arial; margin: 20px; line-height: 1.6;}\n")
            f.write("h1 {color: #3498DB; text-align: center;}\n")
            f.write("table {border-collapse: collapse; width: 100%; margin-bottom: 20px;}\n")
            f.write("th, td {border: 1px solid #ddd; padding: 8px; text-align: left;}\n")
            f.write("th {background-color: #f2f2f2;}\n</style>\n</head>\n<body>\n")
            f.write("<h1>Memory Capture Report</h1>\n<table>\n")
            
            for key, value in report_data:
                f.write(f"<tr><th>{key}</th><td>{html.escape(str(value))}</td></tr>\n")
            
            f.write("</table>\n</body>\n</html>")
    
    elif report_format.lower() == "docx":
        doc = Document()
        doc.add_heading('Memory Capture Report', 0)
        table = doc.add_table(rows=1, cols=2)
        hdr_cells = table.rows[0].cells
        hdr_cells[0].text = 'Field'
        hdr_cells[1].text = 'Value'
        
        for key, value in report_data:
            row_cells = table.add_row().cells
            row_cells[0].text = key
            row_cells[1].text = str(value)
        
        doc.save(report_file)
    
    elif report_format.lower() == "json":
        report_dict = {k.strip(':'): v for k, v in report_data}
        with open(report_file, "w", encoding='utf-8') as f:
            json.dump(report_dict, f, indent=4, ensure_ascii=False)
    
    logging.info(f"Report generated at {report_file}")
    return report_file

class MemoryCaptureApp:
    def __init__(self, root):
        self.root = root
        self.root.title("BitMem")
        self.root.geometry("900x700")
        
        self.user_data = {}
        self.output_file = ""
        self.capture_active = False
        self.capture_thread = None
        self.capture_process = None
        self.capture_start_time = None
        self.capture_bytes_copied = 0
        self.total_memory_size = psutil.virtual_memory().total
        self.hash_algorithm = StringVar(value="sha256")
        self.resume_capture = False
        self.partial_capture_path = None
        self.current_step = 1
        
        self.enable_compression = False
        self.enable_volatility = False
        
        self.config = load_config()
        self.load_icons()
        
        icon_path = ASSETS_DIR / "newbitmemico.ico"
        if icon_path.exists():
            try:
                self.root.iconbitmap(str(icon_path))
            except Exception as e:
                logging.error(f"Error setting window icon: {e}")

        background_image_path = IMAGES_DIR / "image.jpg"
        if background_image_path.exists():
            try:
                self.bg_image = Image.open(background_image_path)
                self.background_photo = CTkImage(light_image=self.bg_image, 
                                               dark_image=self.bg_image,
                                               size=(self.root.winfo_screenwidth(), 
                                                     self.root.winfo_screenheight()))
                self.background_label = ctk.CTkLabel(root, image=self.background_photo, text="")
                self.background_label.place(x=0, y=0, relwidth=1, relheight=1)
            except Exception as e:
                logging.error(f"Error loading background image: {e}")

        self.main_container = ctk.CTkFrame(root, fg_color=SECONDARY_COLOR, corner_radius=15)
        self.main_container.place(relx=0.5, rely=0.5, anchor="center", relwidth=0.5, relheight=0.9)
        
        self.show_welcome_screen()
    
    def load_icons(self):
        self.icons = {}
        icon_files = {
            'investigator_name': "invname.png",
            'investigator_id': "invid.png",
            'case_name': "casename.png",
            'case_id': "caseid.png",
            'memory_id': "memoryid.png",
            'report_format': "report format.png",
            'hash': "hash.png"
        }
        
        for key, filename in icon_files.items():
            icon_path = ICONS_DIR / filename
            if icon_path.exists():
                try:
                    img = Image.open(icon_path)
                    img = img.resize((20, 20), Image.Resampling.LANCZOS)
                    self.icons[key] = CTkImage(light_image=img, dark_image=img, size=(20, 20))
                except Exception as e:
                    logging.error(f"Error loading {key} icon: {e}")
    
    def clear_container(self):
        for widget in self.main_container.winfo_children():
            widget.destroy()
    
    def show_welcome_screen(self):
        self.current_step = 0
        self.clear_container()
        
        container = ctk.CTkFrame(self.main_container, fg_color="transparent")
        container.pack(expand=True, fill="both", padx=20, pady=20)
        
        title_frame = ctk.CTkFrame(container, fg_color="transparent")
        title_frame.pack(pady=(60, 20))
        
        self.welcome_label = ctk.CTkLabel(
            title_frame,
            text="Welcome!",
            font=("Segoe UI", 14),
            text_color=TEXT_COLOR
        )
        self.welcome_label.pack()
        
        self.line1 = ctk.CTkLabel(
            title_frame,
            text="Capture RAM Image with",
            font=("Segoe UI", 24, "bold"),
            text_color=PRIMARY_COLOR
        )
        self.line1.pack()
        
        self.line2 = ctk.CTkLabel(
            title_frame,
            text="BitMem",
            font=("Segoe UI", 36, "bold"),
            text_color=PRIMARY_COLOR
        )
        self.line2.pack(pady=5)
        
        self.start_btn = ctk.CTkButton(
            container,
            text="Start",
            font=("Segoe UI", 18, "bold"),
            fg_color=PRIMARY_COLOR,
            hover_color=ACCENT_COLOR,
            width=120,
            height=120,
            corner_radius=60,
            command=self.show_step1
        )
        self.start_btn.pack(pady=40)
        
        self.thanks_label = ctk.CTkLabel(
            container,
            text="Thanks for using BitMem!",
            font=("Segoe UI", 14),
            text_color=TEXT_COLOR
        )
        self.thanks_label.pack()
        
        self.add_utility_buttons()
    
    def add_utility_buttons(self):
        self.sys_info_btn = ctk.CTkButton(
            self.main_container, 
            text="ℹ",
            font=("Segoe UI", 16, "bold"),
            fg_color=PRIMARY_COLOR, 
            hover_color=ACCENT_COLOR,
            width=40,
            height=40,
            corner_radius=20,
            command=self.show_system_info
        )
        self.sys_info_btn.place(relx=0.05, rely=0.05, anchor="nw")
        
        self.mode_btn = ctk.CTkButton(
            self.main_container, 
            text="☀" if ctk.get_appearance_mode() == "Dark" else "🌙",
            font=("Segoe UI", 16, "bold"),
            fg_color=PRIMARY_COLOR, 
            hover_color=ACCENT_COLOR,
            width=40,
            height=40,
            corner_radius=20,
            command=self.toggle_mode
        )
        self.mode_btn.place(relx=0.95, rely=0.05, anchor="ne")
    
    def show_system_info(self):
        ram = psutil.virtual_memory()
        cpu_usage = psutil.cpu_percent(interval=1)
        disk_usage = psutil.disk_usage('/')
        uptime = time.time() - psutil.boot_time()
        uptime_hours = int(uptime // 3600)
        uptime_minutes = int((uptime % 3600) // 60)
        
        info = (
            f"Total RAM: {ram.total / (1024 ** 3):.2f} GB\n"
            f"Used RAM: {ram.used / (1024 ** 3):.2f} GB\n"
            f"CPU Usage: {cpu_usage}%\n"
            f"Disk Usage: {disk_usage.percent}%\n"
            f"System Uptime: {uptime_hours}h {uptime_minutes}m"
        )
        show_info(info)
    
    def toggle_mode(self):
        global BACKGROUND_COLOR, PRIMARY_COLOR, SECONDARY_COLOR, ACCENT_COLOR, TEXT_COLOR
        current_mode = ctk.get_appearance_mode()
        if current_mode == "Dark":
            new_mode = "Light"
            BACKGROUND_COLOR = LIGHT_BACKGROUND
            PRIMARY_COLOR = LIGHT_PRIMARY
            SECONDARY_COLOR = LIGHT_SECONDARY
            ACCENT_COLOR = LIGHT_ACCENT
            TEXT_COLOR = LIGHT_TEXT
            self.mode_btn.configure(text="🌙")
        else:
            new_mode = "Dark"
            BACKGROUND_COLOR = DARK_BACKGROUND
            PRIMARY_COLOR = DARK_PRIMARY
            SECONDARY_COLOR = DARK_SECONDARY
            ACCENT_COLOR = DARK_ACCENT
            TEXT_COLOR = DARK_TEXT
            self.mode_btn.configure(text="☀")
        
        ctk.set_appearance_mode(new_mode)
        self.update_colors()
        
        self.config['appearance_mode'] = new_mode
        save_config(self.config)
    
    def update_colors(self):
        self.main_container.configure(fg_color=SECONDARY_COLOR)
        self.sys_info_btn.configure(fg_color=PRIMARY_COLOR, hover_color=ACCENT_COLOR)
        self.mode_btn.configure(fg_color=PRIMARY_COLOR, hover_color=ACCENT_COLOR)
        
        if hasattr(self, 'current_step'):
            if self.current_step == 0:
                self.update_welcome_colors()
            elif self.current_step == 1:
                self.update_step1_colors()
            elif self.current_step == 2:
                self.update_step2_colors()
            elif self.current_step == 3:
                self.update_step3_colors()
    
    def update_welcome_colors(self):
        if hasattr(self, 'welcome_label'):
            self.welcome_label.configure(text_color=TEXT_COLOR)
        if hasattr(self, 'line1'):
            self.line1.configure(text_color=PRIMARY_COLOR)
        if hasattr(self, 'line2'):
            self.line2.configure(text_color=PRIMARY_COLOR)
        if hasattr(self, 'start_btn'):
            self.start_btn.configure(fg_color=PRIMARY_COLOR, hover_color=ACCENT_COLOR)
        if hasattr(self, 'thanks_label'):
            self.thanks_label.configure(text_color=TEXT_COLOR)
    
    def update_step1_colors(self):
        if hasattr(self, 'investigator_name_entry'):
            entries = [
                getattr(self, 'investigator_name_entry', None),
                getattr(self, 'investigator_id_entry', None),
                getattr(self, 'case_name_entry', None),
                getattr(self, 'case_id_entry', None),
                getattr(self, 'memory_id_entry', None)
            ]
            
            for entry in entries:
                if entry:
                    try:
                        entry.configure(fg_color=SECONDARY_COLOR, text_color=TEXT_COLOR)
                    except:
                        pass
            
            if hasattr(self, 'report_format_menu'):
                try:
                    self.report_format_menu.configure(fg_color=SECONDARY_COLOR, text_color=TEXT_COLOR)
                except:
                    pass
            if hasattr(self, 'hash_menu'):
                try:
                    self.hash_menu.configure(fg_color=SECONDARY_COLOR, text_color=TEXT_COLOR)
                except:
                    pass
            
            if hasattr(self, 'input_frame'):
                try:
                    self.input_frame.configure(fg_color=BACKGROUND_COLOR)
                except:
                    pass
    
    def update_step2_colors(self):
        if hasattr(self, 'info_frame'):
            try:
                self.info_frame.configure(fg_color=BACKGROUND_COLOR)
                for label in self.info_frame.winfo_children():
                    if isinstance(label, ctk.CTkLabel):
                        label.configure(text_color=TEXT_COLOR)
            except:
                pass
        
        if hasattr(self, 'selected_file_label'):
            try:
                self.selected_file_label.configure(text_color=TEXT_COLOR)
            except:
                pass
        
        if hasattr(self, 'options_frame'):
            try:
                self.options_frame.configure(fg_color="transparent")
                for widget in self.options_frame.winfo_children():
                    if isinstance(widget, ctk.CTkCheckBox):
                        widget.configure(text_color=TEXT_COLOR)
            except:
                pass
    
    def update_step3_colors(self):
        if hasattr(self, 'info_frame'):
            try:
                self.info_frame.configure(fg_color=BACKGROUND_COLOR)
                for label in self.info_frame.winfo_children():
                    if isinstance(label, ctk.CTkLabel):
                        label.configure(text_color=TEXT_COLOR)
            except:
                pass
        
        if hasattr(self, 'progress_label'):
            try:
                self.progress_label.configure(text_color=TEXT_COLOR)
            except:
                pass
        
        if hasattr(self, 'time_left_label'):
            try:
                self.time_left_label.configure(text_color=TEXT_COLOR)
            except:
                pass
    
    def create_label_with_icon(self, parent, text, icon_key):
        frame = ctk.CTkFrame(parent, fg_color="transparent")
        
        if icon_key in self.icons:
            icon_label = ctk.CTkLabel(frame, image=self.icons[icon_key], text="")
            icon_label.pack(side="left", padx=(0, 5))
        
        label = ctk.CTkLabel(frame, text=text, font=("Segoe UI", 14), text_color=TEXT_COLOR)
        label.pack(side="left")
        
        return frame
    
    def show_step1(self):
        self.current_step = 1
        self.clear_container()
        
        container = ctk.CTkFrame(self.main_container, fg_color="transparent")
        container.pack(expand=True, fill="both", padx=20, pady=20)
        
        title = ctk.CTkLabel(
            container,
            text="Step 1: Enter Case Details",
            font=("Segoe UI", 20, "bold"),
            text_color=PRIMARY_COLOR
        )
        title.pack(pady=20)
        
        self.input_frame = ctk.CTkFrame(container, corner_radius=10, fg_color=BACKGROUND_COLOR)
        self.input_frame.pack(pady=10, padx=20, fill="both", expand=True)
        
        self.input_frame.grid_columnconfigure(0, weight=1)
        self.input_frame.grid_columnconfigure(1, weight=1)

        self.create_label_with_icon(self.input_frame, "Investigator Name:", "investigator_name").grid(row=0, column=0, padx=10, pady=10, sticky="e")
        self.investigator_name_entry = ctk.CTkEntry(self.input_frame, font=("Segoe UI", 14), fg_color=SECONDARY_COLOR, text_color=TEXT_COLOR)
        self.investigator_name_entry.grid(row=0, column=1, padx=10, pady=10, sticky="w")
        if 'investigator_name' in self.user_data:
            self.investigator_name_entry.insert(0, self.user_data['investigator_name'])
        self.investigator_name_entry.focus_set()

        self.create_label_with_icon(self.input_frame, "Investigator ID:", "investigator_id").grid(row=1, column=0, padx=10, pady=10, sticky="e")
        self.investigator_id_entry = ctk.CTkEntry(self.input_frame, font=("Segoe UI", 14), fg_color=SECONDARY_COLOR, text_color=TEXT_COLOR)
        self.investigator_id_entry.grid(row=1, column=1, padx=10, pady=10, sticky="w")
        if 'investigator_id' in self.user_data:
            self.investigator_id_entry.insert(0, self.user_data['investigator_id'])

        self.create_label_with_icon(self.input_frame, "Case Name:", "case_name").grid(row=2, column=0, padx=10, pady=10, sticky="e")
        self.case_name_entry = ctk.CTkEntry(self.input_frame, font=("Segoe UI", 14), fg_color=SECONDARY_COLOR, text_color=TEXT_COLOR)
        self.case_name_entry.grid(row=2, column=1, padx=10, pady=10, sticky="w")
        if 'case_name' in self.user_data:
            self.case_name_entry.insert(0, self.user_data['case_name'])

        self.create_label_with_icon(self.input_frame, "Case ID:", "case_id").grid(row=3, column=0, padx=10, pady=10, sticky="e")
        self.case_id_entry = ctk.CTkEntry(self.input_frame, font=("Segoe UI", 14), fg_color=SECONDARY_COLOR, text_color=TEXT_COLOR)
        self.case_id_entry.grid(row=3, column=1, padx=10, pady=10, sticky="w")
        if 'case_id' in self.user_data:
            self.case_id_entry.insert(0, self.user_data['case_id'])

        self.create_label_with_icon(self.input_frame, "Memory ID:", "memory_id").grid(row=4, column=0, padx=10, pady=10, sticky="e")
        self.memory_id_entry = ctk.CTkEntry(self.input_frame, font=("Segoe UI", 14), fg_color=SECONDARY_COLOR, text_color=TEXT_COLOR)
        self.memory_id_entry.grid(row=4, column=1, padx=10, pady=10, sticky="w")
        if 'memory_id' in self.user_data:
            self.memory_id_entry.insert(0, self.user_data['memory_id'])

        self.create_label_with_icon(self.input_frame, "Report Format:", "report_format").grid(row=5, column=0, padx=10, pady=10, sticky="e")
        self.report_format_var = StringVar(value="pdf")
        if 'report_format' in self.user_data:
            self.report_format_var.set(self.user_data['report_format'])
        self.report_format_menu = ctk.CTkOptionMenu(
            self.input_frame,
            variable=self.report_format_var,
            values=["txt", "pdf", "html", "docx", "json"],
            font=("Segoe UI", 14),
            fg_color=SECONDARY_COLOR,
            text_color=TEXT_COLOR
        )
        self.report_format_menu.grid(row=5, column=1, padx=10, pady=10, sticky="w")

        self.create_label_with_icon(self.input_frame, "Hash Algorithm:", "hash").grid(row=6, column=0, padx=10, pady=10, sticky="e")
        self.hash_algorithm = StringVar(value="sha256")
        if 'hash_algorithm' in self.user_data:
            self.hash_algorithm.set(self.user_data['hash_algorithm'])
        self.hash_menu = ctk.CTkOptionMenu(
            self.input_frame, 
            variable=self.hash_algorithm,
            values=["md5", "sha1", "sha256", "sha512"],
            font=("Segoe UI", 14),
            fg_color=SECONDARY_COLOR,
            text_color=TEXT_COLOR
        )
        self.hash_menu.grid(row=6, column=1, padx=10, pady=10, sticky="w")
        
        button_frame = ctk.CTkFrame(container, fg_color="transparent")
        button_frame.pack(pady=20)
        
        back_btn = ctk.CTkButton(
            button_frame,
            text="←",
            font=("Segoe UI", 18, "bold"),
            fg_color=PRIMARY_COLOR,
            hover_color=ACCENT_COLOR,
            width=60,
            height=60,
            corner_radius=30,
            command=self.show_welcome_screen
        )
        back_btn.pack(side="left", padx=10)
        
        next_btn = ctk.CTkButton(
            button_frame,
            text="→",
            font=("Segoe UI", 18, "bold"),
            fg_color=PRIMARY_COLOR,
            hover_color=ACCENT_COLOR,
            width=60,
            height=60,
            corner_radius=30,
            command=self.validate_step1
        )
        next_btn.pack(side="right", padx=10)
        
        self.investigator_name_entry.bind('<Return>', lambda e: self.investigator_id_entry.focus())
        self.investigator_id_entry.bind('<Return>', lambda e: self.case_name_entry.focus())
        self.case_name_entry.bind('<Return>', lambda e: self.case_id_entry.focus())
        self.case_id_entry.bind('<Return>', lambda e: self.memory_id_entry.focus())
        self.memory_id_entry.bind('<Return>', lambda e: self.report_format_menu.focus())
        self.report_format_menu.bind('<Return>', lambda e: self.hash_menu.focus())
        self.hash_menu.bind('<Return>', lambda e: self.validate_step1())
        
        self.add_utility_buttons()
    
    def validate_step1(self):
        if not all([
            self.investigator_name_entry.get(),
            self.investigator_id_entry.get(),
            self.case_name_entry.get(),
            self.case_id_entry.get(),
            self.memory_id_entry.get()
        ]):
            show_error("Please fill all fields")
            return
        
        self.user_data = {
            "investigator_name": self.investigator_name_entry.get(),
            "investigator_id": self.investigator_id_entry.get(),
            "case_name": self.case_name_entry.get(),
            "case_id": self.case_id_entry.get(),
            "memory_id": self.memory_id_entry.get(),
            "report_format": self.report_format_var.get(),
            "hash_algorithm": self.hash_algorithm.get()
        }
        
        self.show_step2()
    
    def show_step2(self):
        self.current_step = 2
        self.clear_container()
        
        container = ctk.CTkFrame(self.main_container, fg_color="transparent")
        container.pack(expand=True, fill="both", padx=20, pady=20)
        
        title = ctk.CTkLabel(
            container,
            text="Step 2: Select Output and Options",
            font=("Segoe UI", 20, "bold"),
            text_color=PRIMARY_COLOR
        )
        title.pack(pady=20)
        
        self.info_frame = ctk.CTkFrame(container, corner_radius=10, fg_color=BACKGROUND_COLOR)
        self.info_frame.pack(pady=10, padx=20, fill="x")
        
        ctk.CTkLabel(
            self.info_frame, 
            text=f"Investigator: {self.user_data['investigator_name']} (ID: {self.user_data['investigator_id']})",
            font=("Segoe UI", 14),
            text_color=TEXT_COLOR
        ).pack(pady=5)
        
        ctk.CTkLabel(
            self.info_frame, 
            text=f"Case: {self.user_data['case_name']} (ID: {self.user_data['case_id']})",
            font=("Segoe UI", 14),
            text_color=TEXT_COLOR
        ).pack(pady=5)
        
        select_btn_frame = ctk.CTkFrame(container, fg_color="transparent")
        select_btn_frame.pack(pady=20)
        
        select_btn = ctk.CTkButton(
            select_btn_frame,
            text="📁 Select Output File",
            font=("Segoe UI", 14, "bold"),
            fg_color=PRIMARY_COLOR,
            hover_color=ACCENT_COLOR,
            command=self.select_file
        )
        select_btn.pack(pady=10)
        
        self.selected_file_label = ctk.CTkLabel(
            select_btn_frame,
            text="No file selected" if not self.output_file else f"Selected: {self.output_file}",
            font=("Segoe UI", 12),
            text_color=TEXT_COLOR,
            wraplength=400
        )
        self.selected_file_label.pack(pady=5)
        
        self.options_frame = ctk.CTkFrame(container, fg_color="transparent")
        self.options_frame.pack(pady=10, fill="x")
        
        centered_frame = ctk.CTkFrame(self.options_frame, fg_color="transparent")
        centered_frame.pack(pady=5)
        
        self.compression_var = ctk.BooleanVar(value=self.enable_compression)
        self.enable_compression_check = ctk.CTkCheckBox(
            centered_frame,
            text="Compress RAM image after capture",
            variable=self.compression_var,
            command=self.toggle_compression
        )
        self.enable_compression_check.pack(pady=5)
        
        self.volatility_var = ctk.BooleanVar(value=self.enable_volatility)
        self.enable_volatility_check = ctk.CTkCheckBox(
            centered_frame,
            text="Analyze with Volatility",
            variable=self.volatility_var,
            command=self.toggle_volatility
        )
        self.enable_volatility_check.pack(pady=5)
        
        button_frame = ctk.CTkFrame(container, fg_color="transparent")
        button_frame.pack(pady=20)
        
        back_btn = ctk.CTkButton(
            button_frame,
            text="←",
            font=("Segoe UI", 18, "bold"),
            fg_color=PRIMARY_COLOR,
            hover_color=ACCENT_COLOR,
            width=60,
            height=60,
            corner_radius=30,
            command=self.show_step1
        )
        back_btn.pack(side="left", padx=10)
        
        self.next_btn_step2 = ctk.CTkButton(
            button_frame,
            text="→",
            font=("Segoe UI", 18, "bold"),
            fg_color=PRIMARY_COLOR,
            hover_color=ACCENT_COLOR,
            width=60,
            height=60,
            corner_radius=30,
            state="disabled" if not self.output_file else "normal",
            command=self.show_step3
        )
        self.next_btn_step2.pack(side="right", padx=10)
        
        self.root.bind('<Return>', lambda event: self.select_file())
        self.add_utility_buttons()
    
    def toggle_compression(self):
        self.enable_compression = self.compression_var.get()
        logging.info(f"Compression {'enabled' if self.enable_compression else 'disabled'}")
    
    def toggle_volatility(self):
        self.enable_volatility = self.volatility_var.get()
        logging.info(f"Volatility analysis {'enabled' if self.enable_volatility else 'disabled'}")
    
    def select_file(self):
        file_path = filedialog.asksaveasfilename(
            title="Select location to save memory image",
            defaultextension=".raw",
            filetypes=[("RAW files", "*.raw"), ("All Files", "*.*")]
        )
        
        if file_path:
            self.output_file = file_path
            self.selected_file_label.configure(text=f"Selected: {self.output_file}")
            self.next_btn_step2.configure(state="normal")
            self.root.unbind('<Return>')
            self.root.bind('<Return>', lambda event: self.show_step3())
        else:
            show_error("No file selected. Please try again.")
    
    def show_step3(self):
        self.current_step = 3
        self.clear_container()
        
        container = ctk.CTkFrame(self.main_container, fg_color="transparent")
        container.pack(expand=True, fill="both", padx=20, pady=20)
        
        title = ctk.CTkLabel(
            container,
            text="Step 3: Capture Memory",
            font=("Segoe UI", 20, "bold"),
            text_color=PRIMARY_COLOR
        )
        title.pack(pady=20)
        
        self.info_frame = ctk.CTkFrame(container, corner_radius=10, fg_color=BACKGROUND_COLOR)
        self.info_frame.pack(pady=10, padx=20, fill="x")
        
        ctk.CTkLabel(
            self.info_frame, 
            text=f"Case: {self.user_data['case_name']}",
            font=("Segoe UI", 14),
            text_color=TEXT_COLOR
        ).pack(pady=5)
        
        ctk.CTkLabel(
            self.info_frame, 
            text=f"Output File: {self.output_file}",
            font=("Segoe UI", 14),
            text_color=TEXT_COLOR
        ).pack(pady=5)
        
        features = []
        if self.enable_compression:
            features.append("Compression")
        if self.enable_volatility:
            features.append("Volatility Analysis")
        
        if features:
            ctk.CTkLabel(
                self.info_frame,
                text=f"Enabled features: {', '.join(features)}",
                font=("Segoe UI", 12),
                text_color=TEXT_COLOR
            ).pack(pady=5)
        
        progress_container = ctk.CTkFrame(container, fg_color="transparent")
        progress_container.pack(pady=40, fill="x", expand=True)
        
        self.progress_bar = ctk.CTkProgressBar(
            progress_container,
            mode="determinate",
            width=500,
            height=30,
            fg_color=SECONDARY_COLOR,
            progress_color=PRIMARY_COLOR
        )
        self.progress_bar.pack(pady=20)
        self.progress_bar.set(0)
        
        self.progress_label = ctk.CTkLabel(
            progress_container,
            text="Ready to capture... 0%",
            font=("Segoe UI", 16),
            text_color=TEXT_COLOR
        )
        self.progress_label.pack(pady=10)
        
        self.time_left_label = ctk.CTkLabel(
            progress_container,
            text="Estimated time remaining: --",
            font=("Segoe UI", 14),
            text_color=TEXT_COLOR
        )
        self.time_left_label.pack(pady=5)
        
        button_frame = ctk.CTkFrame(container, fg_color="transparent")
        button_frame.pack(side="bottom", pady=20)
        
        back_btn = ctk.CTkButton(
            button_frame,
            text="←",
            font=("Segoe UI", 18, "bold"),
            fg_color=PRIMARY_COLOR,
            hover_color=ACCENT_COLOR,
            width=60,
            height=60,
            corner_radius=30,
            command=self.show_step2
        )
        back_btn.pack(side="left", padx=10)
        
        self.capture_btn = ctk.CTkButton(
            button_frame,
            text="⚡",
            font=("Segoe UI", 18, "bold"),
            fg_color=PRIMARY_COLOR,
            hover_color=ACCENT_COLOR,
            width=60,
            height=60,
            corner_radius=30,
            command=self.start_capture
        )
        self.capture_btn.pack(side="right", padx=10)
        
        self.root.bind('<Return>', lambda event: self.start_capture())
        self.add_utility_buttons()

    def start_capture(self):
        if self.resume_capture and self.partial_capture_path:
            resume_msg = f"Resume previous capture?\nPartial file: {os.path.getsize(self.partial_capture_path)/1024/1024:.2f} MB"
            if messagebox.askyesno("Resume Capture", resume_msg):
                self.output_file = self.partial_capture_path
                self.capture_bytes_copied = os.path.getsize(self.output_file)
            else:
                self.resume_capture = False
                self.partial_capture_path = None
        
        if not self.resume_capture:
            self.capture_bytes_copied = 0
            self.capture_start_time = time.time()
            self.total_memory_size = psutil.virtual_memory().total
        
        self.capture_active = True
        self.capture_btn.configure(text="■", command=self.stop_capture)
        self.progress_label.configure(text="Initializing capture... 0%")
        
        self.capture_thread = threading.Thread(
            target=self.run_capture_process,
            args=(str(BASE_DIR / "winpmem_mini.exe"), self.output_file),
            daemon=True
        )
        self.capture_thread.start()

    def run_capture_process(self, winpmem_path, output_file):
        command = [winpmem_path, output_file]
        start_time = time.time()
        last_update_time = start_time
        last_size = 0
        
        mem_info = psutil.virtual_memory()
        self.total_memory_size = mem_info.total
        self.capture_start_time = start_time
        
        try:
            self.capture_process = subprocess.Popen(
                command, 
                stdout=subprocess.PIPE, 
                stderr=subprocess.PIPE
            )
            
            time.sleep(1)
            
            while self.capture_active:
                current_time = time.time()
                
                if self.capture_process.poll() is not None:
                    break
                
                try:
                    current_size = os.path.getsize(output_file)
                except FileNotFoundError:
                    current_size = 0
                
                progress = min((current_size) / self.total_memory_size, 1.0)
                
                if current_time - last_update_time >= 0.5 or abs(current_size - last_size) > (self.total_memory_size * 0.01):
                    self.progress_label.configure(text=f"Capturing... {progress*100:.1f}%")
                    self.progress_bar.set(progress)
                    
                    elapsed = current_time - start_time
                    if progress > 0.01 and elapsed > 0:
                        transfer_rate = (current_size - last_size) / (1024 * 1024 * (current_time - last_update_time)) if current_time > last_update_time else 0
                        remaining = max((self.total_memory_size - current_size) / (current_size / elapsed) if current_size > 0 else 0, 0)
                        self.time_left_label.configure(text=f"Time left: {remaining:.1f} sec | Speed: {transfer_rate:.1f} MB/s")
                    
                    last_size = current_size
                    last_update_time = current_time
                
                time.sleep(0.1)
            
            if not self.capture_active:
                self.root.after(0, lambda: self.finish_capture(stopped=True))
                return
            
            self.progress_label.configure(text="Finalizing... 100%")
            self.progress_bar.set(1)
            self.time_left_label.configure(text="Finishing up...")
            
            if os.path.exists(output_file):
                final_size = os.path.getsize(output_file)
                if final_size < self.total_memory_size * 0.95:
                    self.root.after(0, lambda: self.progress_label.configure(text="Capture incomplete!"))
                    self.root.after(0, lambda: show_error(
                        f"Capture did not complete (only {final_size/1024/1024:.1f} MB of {self.total_memory_size/1024/1024:.1f} MB captured)"))
                    return
            
            hash_value = calculate_hash(output_file, self.user_data["hash_algorithm"])
            image_size = os.path.getsize(output_file)
            elapsed_time = time.time() - start_time
            
            report_file = generate_report(
                output_file,
                self.user_data["investigator_name"],
                int(self.user_data["investigator_id"]),
                self.user_data["case_name"],
                int(self.user_data["case_id"]),
                int(self.user_data["memory_id"]),
                hash_value,
                image_size,
                elapsed_time,
                self.user_data["report_format"],
                self.user_data["hash_algorithm"]
            )
            
            result_files = {"image": output_file, "report": report_file}
            volatility_report = None
            
            if self.enable_volatility:
                volatility_report = analyze_with_volatility(
                    output_file,
                    os.path.dirname(output_file)
                )
                if volatility_report:
                    result_files["volatility"] = volatility_report
            
            if self.enable_compression:
                compressed_image = compress_file(output_file)
                if compressed_image:
                    result_files["image"] = compressed_image
                    try:
                        os.remove(output_file)
                    except Exception as e:
                        logging.error(f"Could not remove original file: {e}")
                
                compressed_report = compress_file(report_file)
                if compressed_report:
                    result_files["report"] = compressed_report
                    try:
                        os.remove(report_file)
                    except Exception as e:
                        logging.error(f"Could not remove original report: {e}")
                
                if volatility_report and self.enable_compression:
                    compressed_volatility = compress_file(volatility_report)
                    if compressed_volatility:
                        result_files["volatility"] = compressed_volatility
                        try:
                            os.remove(volatility_report)
                        except Exception as e:
                            logging.error(f"Could not remove original volatility report: {e}")
            
            self.root.after(0, lambda: self.finish_capture(
                success=True,
                output_file=result_files["image"],
                report_file=result_files["report"],
                volatility_report=result_files.get("volatility")
            ))
            
        except Exception as e:
            self.root.after(0, lambda: self.progress_label.configure(text=f"Error: {str(e)}"))
            self.root.after(0, lambda: show_error(f"An exception occurred: {str(e)}"))
        finally:
            self.capture_active = False
            if hasattr(self, 'capture_process') and self.capture_process:
                try:
                    self.capture_process.terminate()
                except:
                    pass
            
    def stop_capture(self):
        self.capture_active = False
        if self.capture_process:
            self.capture_process.terminate()
        
        if os.path.exists(self.output_file):
            file_size = os.path.getsize(self.output_file)
            if file_size > 0 and file_size < self.total_memory_size:
                if messagebox.askyesno("Partial Capture", "Save partial capture for resuming later?"):
                    self.partial_capture_path = self.output_file
                    self.resume_capture = True
                    self.capture_bytes_copied = file_size
    
    def finish_capture(self, stopped=False, success=False, output_file="", report_file="", volatility_report=None):
        self.capture_active = False
        self.capture_btn.configure(
            text="⚡",
            command=self.start_capture,
            state="normal"
        )
        
        if stopped:
            self.progress_label.configure(text="Capture stopped")
            show_info("Capture process was stopped")
        elif success:
            self.progress_label.configure(text="Capture complete! 100%")
            self.progress_bar.set(1)
            
            success_msg = (
                f"RAM image captured successfully!\n"
                f"Image saved at: {output_file}\n"
                f"Report saved at: {report_file}"
            )
            
            if volatility_report:
                success_msg += f"\nVolatility report: {volatility_report}"
            
            show_info(success_msg)
            self.resume_capture = False
            self.partial_capture_path = None
        else:
            self.progress_label.configure(text="Capture failed!")
            self.time_left_label.configure(text="")

def create_gui():
    root = ctk.CTk()
    app = MemoryCaptureApp(root)
    root.mainloop()

if __name__ == "__main__":
    create_gui()