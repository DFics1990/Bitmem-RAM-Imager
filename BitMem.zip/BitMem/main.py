import os
import subprocess
import threading
import customtkinter as ctk
from tkinter import filedialog, messagebox, StringVar
import hashlib
from datetime import datetime
import time
import psutil
from fpdf import FPDF
from PIL import Image
from customtkinter import CTkImage
from pathlib import Path

# Global sets to store used IDs
used_investigator_ids = set()
used_case_ids = set()
used_memory_ids = set()

# Configure appearance
ctk.set_appearance_mode("Dark")
ctk.set_default_color_theme("dark-blue")

# Color Theme
DARK_BACKGROUND = "#1E2A38"
DARK_PRIMARY = "#3498DB"
DARK_SECONDARY = "#2C3E50"
DARK_ACCENT = "#2980B9"
DARK_TEXT = "#ECF0F1"

LIGHT_BACKGROUND = "#FFFFFF"
LIGHT_PRIMARY = "#3498DB"
LIGHT_SECONDARY = "#BDC3C7"
LIGHT_ACCENT = "#2980B9"
LIGHT_TEXT = "#2C3E50"

# Global color variables
BACKGROUND_COLOR = DARK_BACKGROUND
PRIMARY_COLOR = DARK_PRIMARY
SECONDARY_COLOR = DARK_SECONDARY
ACCENT_COLOR = DARK_ACCENT
TEXT_COLOR = DARK_TEXT

# Base directory - where the main script is located
BASE_DIR = Path(__file__).parent
ASSETS_DIR = BASE_DIR / "assets"
ICONS_DIR = ASSETS_DIR / "icons"
IMAGES_DIR = ASSETS_DIR / "images"

def calculate_hash(file_path, algorithm="sha256"):
    hash_func = hashlib.new(algorithm)
    with open(file_path, "rb") as f:
        for chunk in iter(lambda: f.read(4096), b""):
            hash_func.update(chunk)
    return hash_func.hexdigest()

def generate_report(output_file, investigator_name, investigator_id, case_name, case_id, memory_id, hash_value, image_size, elapsed_time, report_format):
    report_file_name = f"Case-{case_name.replace(' ', '_')}_Report.{report_format}"
    report_file = os.path.join(os.path.dirname(output_file), report_file_name)
    
    capture_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    report_content = f"""
    Memory Capture Report
    =====================
    Investigator Name: {investigator_name}
    Investigator ID: {investigator_id}
    Case Name: {case_name}
    Case ID: {case_id}
    Memory ID: {memory_id}
    Capture Date and Time: {capture_time}
    Image Size: {image_size} bytes
    Hash Value ({hashlib.new("sha256").name}): {hash_value}
    Image Location: {output_file}
    Time Taken: {elapsed_time:.2f} seconds
    """
    
    if report_format == "txt":
        with open(report_file, "w") as f:
            f.write(report_content)
    elif report_format == "pdf":
        pdf = FPDF()
        pdf.add_page()
        pdf.set_font("Arial", size=12)
        pdf.multi_cell(0, 10, report_content)
        pdf.output(report_file)
    
    return report_file

def validate_unique_ids(investigator_id, case_id, memory_id):
    errors = []
    if investigator_id in used_investigator_ids:
        errors.append("Investigator ID is already in use.")
    if case_id in used_case_ids:
        errors.append("Case ID is already in use.")
    if memory_id in used_memory_ids:
        errors.append("Memory ID is already in use.")
    return errors

class MemoryCaptureApp:
    def __init__(self, root):
        self.root = root
        self.root.title("BitMem")
        self.root.geometry("900x700")
        
        # Data storage
        self.user_data = {}
        self.output_file = ""
        self.capture_active = False
        self.capture_thread = None
        self.capture_process = None
        
        # Load all icons
        self.load_icons()
        
        # Set icon
        icon_path = ASSETS_DIR / "newbitmemico.ico"
        if icon_path.exists():
            self.root.iconbitmap(str(icon_path))

        # Background image
        background_image_path = IMAGES_DIR / "newbackback.jpg"
        if background_image_path.exists():
            try:
                self.bg_image = Image.open(background_image_path)
                self.background_photo = CTkImage(light_image=self.bg_image, 
                                               dark_image=self.bg_image,
                                               size=(self.root.winfo_screenwidth(), 
                                                     self.root.winfo_screenheight()))
                self.background_label = ctk.CTkLabel(root, image=self.background_photo, text="")
                self.background_label.place(x=0, y=0, relwidth=1, relheight=1)
            except Exception as e:
                print(f"Error loading background image: {e}")

        # Create main container - vertical rectangle
        self.main_container = ctk.CTkFrame(root, fg_color=SECONDARY_COLOR, corner_radius=15)
        self.main_container.place(relx=0.5, rely=0.5, anchor="center", relwidth=0.4, relheight=0.7)
        
        # Show welcome screen first
        self.show_welcome_screen()
    
    def load_icons(self):
        """Load all required icons as CTkImage"""
        self.icons = {}
        icon_files = {
            'investigator_name': "invname.png",
            'investigator_id': "invid.png",
            'case_name': "casename.png",
            'case_id': "caseid.png",
            'memory_id': "memoryid.png",
            'report_format': "report format.png"
        }
        
        for key, filename in icon_files.items():
            icon_path = ICONS_DIR / filename
            if icon_path.exists():
                try:
                    img = Image.open(icon_path)
                    img = img.resize((20, 20), Image.Resampling.LANCZOS)
                    self.icons[key] = CTkImage(light_image=img, dark_image=img, size=(20, 20))
                except Exception as e:
                    print(f"Error loading {key} icon: {e}")
    
    def clear_container(self):
        """Clear all widgets from the main container"""
        for widget in self.main_container.winfo_children():
            widget.destroy()
    
    def show_welcome_screen(self):
        """Initial welcome screen"""
        self.clear_container()
        
        # Center the content vertically
        container = ctk.CTkFrame(self.main_container, fg_color="transparent")
        container.pack(expand=True, fill="both", padx=20, pady=20)
        
        # Title with two lines and proper spacing
        title_frame = ctk.CTkFrame(container, fg_color="transparent")
        title_frame.pack(pady=(20, 40))
        
        line1 = ctk.CTkLabel(
            title_frame,
            text="Capture RAM Image with",
            font=("Segoe UI", 24, "bold"),
            text_color=PRIMARY_COLOR
        )
        line1.pack()
        
        line2 = ctk.CTkLabel(
            title_frame,
            text="BitMem",
            font=("Segoe UI", 24, "bold"),
            text_color=PRIMARY_COLOR
        )
        line2.pack(padx=(40, 0))  # Add left padding to align with first line
        
        # Start button - now circular
        start_btn = ctk.CTkButton(
            container,
            text="Start",
            font=("Segoe UI", 18, "bold"),
            fg_color=PRIMARY_COLOR,
            hover_color=ACCENT_COLOR,
            width=120,
            height=120,
            corner_radius=60,  # Makes it circular
            command=self.show_step1
        )
        start_btn.pack(pady=20)
        
        # Add system info and mode switch buttons (top corners)
        self.add_utility_buttons()
    
    def add_utility_buttons(self):
        """Add system info and mode switch buttons"""
        # System Info Button - circular
        sys_info_btn = ctk.CTkButton(
            self.main_container, 
            text="ℹ",  # Using info symbol
            font=("Segoe UI", 16, "bold"),
            fg_color=PRIMARY_COLOR, 
            hover_color=ACCENT_COLOR,
            width=40,
            height=40,
            corner_radius=20,
            command=self.show_system_info
        )
        sys_info_btn.place(relx=0.05, rely=0.05, anchor="nw")
        
        # Mode Switch Button - circular
        self.mode_btn = ctk.CTkButton(
            self.main_container, 
            text="☀",  # Sun symbol for light mode
            font=("Segoe UI", 16, "bold"),
            fg_color=PRIMARY_COLOR, 
            hover_color=ACCENT_COLOR,
            width=40,
            height=40,
            corner_radius=20,
            command=self.toggle_mode
        )
        self.mode_btn.place(relx=0.95, rely=0.05, anchor="ne")
    
    def show_system_info(self):
        """Show system information"""
        ram = psutil.virtual_memory()
        cpu_usage = psutil.cpu_percent(interval=1)
        disk_usage = psutil.disk_usage('/')
        uptime = time.time() - psutil.boot_time()
        uptime_hours = int(uptime // 3600)
        uptime_minutes = int((uptime % 3600) // 60)
        
        info = (
            f"Total RAM: {ram.total / (1024 ** 3):.2f} GB\n"
            f"Used RAM: {ram.used / (1024 ** 3):.2f} GB\n"
            f"CPU Usage: {cpu_usage}%\n"
            f"Disk Usage: {disk_usage.percent}%\n"
            f"System Uptime: {uptime_hours}h {uptime_minutes}m"
        )
        messagebox.showinfo("System Information", info)
    
    def toggle_mode(self):
        """Toggle between dark/light mode"""
        global BACKGROUND_COLOR, PRIMARY_COLOR, SECONDARY_COLOR, ACCENT_COLOR, TEXT_COLOR
        current_mode = ctk.get_appearance_mode()
        if current_mode == "Dark":
            new_mode = "Light"
            BACKGROUND_COLOR = LIGHT_BACKGROUND
            PRIMARY_COLOR = LIGHT_PRIMARY
            SECONDARY_COLOR = LIGHT_SECONDARY
            ACCENT_COLOR = LIGHT_ACCENT
            TEXT_COLOR = LIGHT_TEXT
            self.mode_btn.configure(text="☀")  # Sun symbol for light mode
        else:
            new_mode = "Dark"
            BACKGROUND_COLOR = DARK_BACKGROUND
            PRIMARY_COLOR = DARK_PRIMARY
            SECONDARY_COLOR = DARK_SECONDARY
            ACCENT_COLOR = DARK_ACCENT
            TEXT_COLOR = DARK_TEXT
            self.mode_btn.configure(text="🌙")  # Moon symbol for dark mode
        ctk.set_appearance_mode(new_mode)
        self.update_colors(new_mode)
    
    def update_colors(self, mode):
        """Update colors when theme changes"""
        self.main_container.configure(fg_color=SECONDARY_COLOR)
        for widget in self.main_container.winfo_children():
            if isinstance(widget, ctk.CTkLabel):
                if "Step" in widget.cget("text"):
                    widget.configure(text_color=PRIMARY_COLOR)
                else:
                    widget.configure(text_color=TEXT_COLOR)
            elif isinstance(widget, ctk.CTkButton) and widget not in [self.mode_btn]:
                widget.configure(fg_color=PRIMARY_COLOR, hover_color=ACCENT_COLOR, text_color=TEXT_COLOR)
    
    def create_label_with_icon(self, parent, text, icon_key):
        """Create a label with an icon next to it"""
        frame = ctk.CTkFrame(parent, fg_color="transparent")
        
        if icon_key in self.icons:
            icon_label = ctk.CTkLabel(frame, image=self.icons[icon_key], text="")
            icon_label.pack(side="left", padx=(0, 5))
        
        label = ctk.CTkLabel(frame, text=text, font=("Segoe UI", 14), text_color=TEXT_COLOR)
        label.pack(side="left")
        
        return frame
    
    def show_step1(self):
        """Step 1: User information input"""
        self.clear_container()
        
        # Create a container for better centering
        container = ctk.CTkFrame(self.main_container, fg_color="transparent")
        container.pack(expand=True, fill="both", padx=20, pady=20)
        
        title = ctk.CTkLabel(
            container,
            text="Step 1: Enter Case Details",
            font=("Segoe UI", 20, "bold"),
            text_color=PRIMARY_COLOR
        )
        title.pack(pady=20)
        
        # Input frame
        input_frame = ctk.CTkFrame(container, corner_radius=10, fg_color=BACKGROUND_COLOR)
        input_frame.pack(pady=10, padx=20, fill="both", expand=True)
        
        # Input fields grid
        input_frame.grid_columnconfigure(0, weight=1)
        input_frame.grid_columnconfigure(1, weight=1)

        # Investigator Details with icons
        self.create_label_with_icon(input_frame, "Investigator Name:", "investigator_name").grid(row=0, column=0, padx=10, pady=10, sticky="e")
        self.investigator_name_entry = ctk.CTkEntry(input_frame, font=("Segoe UI", 14), fg_color=SECONDARY_COLOR, text_color=TEXT_COLOR)
        self.investigator_name_entry.grid(row=0, column=1, padx=10, pady=10, sticky="w")

        self.create_label_with_icon(input_frame, "Investigator ID:", "investigator_id").grid(row=1, column=0, padx=10, pady=10, sticky="e")
        self.investigator_id_entry = ctk.CTkEntry(input_frame, font=("Segoe UI", 14), fg_color=SECONDARY_COLOR, text_color=TEXT_COLOR)
        self.investigator_id_entry.grid(row=1, column=1, padx=10, pady=10, sticky="w")

        # Case Details with icons
        self.create_label_with_icon(input_frame, "Case Name:", "case_name").grid(row=2, column=0, padx=10, pady=10, sticky="e")
        self.case_name_entry = ctk.CTkEntry(input_frame, font=("Segoe UI", 14), fg_color=SECONDARY_COLOR, text_color=TEXT_COLOR)
        self.case_name_entry.grid(row=2, column=1, padx=10, pady=10, sticky="w")

        self.create_label_with_icon(input_frame, "Case ID:", "case_id").grid(row=3, column=0, padx=10, pady=10, sticky="e")
        self.case_id_entry = ctk.CTkEntry(input_frame, font=("Segoe UI", 14), fg_color=SECONDARY_COLOR, text_color=TEXT_COLOR)
        self.case_id_entry.grid(row=3, column=1, padx=10, pady=10, sticky="w")

        # Memory ID with icon
        self.create_label_with_icon(input_frame, "Memory ID:", "memory_id").grid(row=4, column=0, padx=10, pady=10, sticky="e")
        self.memory_id_entry = ctk.CTkEntry(input_frame, font=("Segoe UI", 14), fg_color=SECONDARY_COLOR, text_color=TEXT_COLOR)
        self.memory_id_entry.grid(row=4, column=1, padx=10, pady=10, sticky="w")

        # Report Format with icon
        self.create_label_with_icon(input_frame, "Report Format:", "report_format").grid(row=5, column=0, padx=10, pady=10, sticky="e")
        self.report_format_var = StringVar(value="txt")
        report_format_menu = ctk.CTkOptionMenu(input_frame, variable=self.report_format_var, values=["txt", "pdf"], font=("Segoe UI", 14), fg_color=SECONDARY_COLOR, text_color=TEXT_COLOR)
        report_format_menu.grid(row=5, column=1, padx=10, pady=10, sticky="w")
        
        # Navigation buttons - now circular
        button_frame = ctk.CTkFrame(container)
        button_frame.pack(pady=20)
        
        back_btn = ctk.CTkButton(
            button_frame,
            text="←",
            font=("Segoe UI", 18, "bold"),
            fg_color=PRIMARY_COLOR,
            hover_color=ACCENT_COLOR,
            width=60,
            height=60,
            corner_radius=30,
            command=self.show_welcome_screen
        )
        back_btn.pack(side="left", padx=10)
        
        next_btn = ctk.CTkButton(
            button_frame,
            text="→",
            font=("Segoe UI", 18, "bold"),
            fg_color=PRIMARY_COLOR,
            hover_color=ACCENT_COLOR,
            width=60,
            height=60,
            corner_radius=30,
            command=self.validate_step1
        )
        next_btn.pack(side="right", padx=10)
        
        # Add utility buttons
        self.add_utility_buttons()
    
    def validate_step1(self):
        """Validate step 1 inputs before proceeding"""
        if not all([
            self.investigator_name_entry.get(),
            self.investigator_id_entry.get(),
            self.case_name_entry.get(),
            self.case_id_entry.get(),
            self.memory_id_entry.get()
        ]):
            messagebox.showerror("Error", "Please fill all fields")
            return
        
        # Store data for later use
        self.user_data = {
            "investigator_name": self.investigator_name_entry.get(),
            "investigator_id": self.investigator_id_entry.get(),
            "case_name": self.case_name_entry.get(),
            "case_id": self.case_id_entry.get(),
            "memory_id": self.memory_id_entry.get(),
            "report_format": self.report_format_var.get()
        }
        
        self.show_step2()
    
    def show_step2(self):
        """Step 2: File selection"""
        self.clear_container()
        
        # Create a container for better centering
        container = ctk.CTkFrame(self.main_container, fg_color="transparent")
        container.pack(expand=True, fill="both", padx=20, pady=20)
        
        title = ctk.CTkLabel(
            container,
            text="Step 2: Select Output Location",
            font=("Segoe UI", 20, "bold"),
            text_color=PRIMARY_COLOR
        )
        title.pack(pady=20)
        
        # Case info display
        info_frame = ctk.CTkFrame(container, corner_radius=10, fg_color=BACKGROUND_COLOR)
        info_frame.pack(pady=10, padx=20, fill="x")
        
        ctk.CTkLabel(
            info_frame, 
            text=f"Investigator: {self.user_data['investigator_name']} (ID: {self.user_data['investigator_id']})",
            font=("Segoe UI", 14),
            text_color=TEXT_COLOR
        ).pack(pady=5)
        
        ctk.CTkLabel(
            info_frame, 
            text=f"Case: {self.user_data['case_name']} (ID: {self.user_data['case_id']})",
            font=("Segoe UI", 14),
            text_color=TEXT_COLOR
        ).pack(pady=5)
        
        # Add select file button with folder icon
        select_btn_frame = ctk.CTkFrame(container, fg_color="transparent")
        select_btn_frame.pack(pady=20)
        
        select_btn = ctk.CTkButton(
            select_btn_frame,
            text="📁 Select Output File",  # Folder icon
            font=("Segoe UI", 14, "bold"),
            fg_color=PRIMARY_COLOR,
            hover_color=ACCENT_COLOR,
            command=self.select_file
        )
        select_btn.pack(pady=10)
        
        # Navigation buttons - circular
        button_frame = ctk.CTkFrame(container)
        button_frame.pack(pady=20)
        
        back_btn = ctk.CTkButton(
            button_frame,
            text="←",
            font=("Segoe UI", 18, "bold"),
            fg_color=PRIMARY_COLOR,
            hover_color=ACCENT_COLOR,
            width=60,
            height=60,
            corner_radius=30,
            command=self.show_step1
        )
        back_btn.pack(side="left", padx=10)
        
        next_btn = ctk.CTkButton(
            button_frame,
            text="→",
            font=("Segoe UI", 18, "bold"),
            fg_color=PRIMARY_COLOR,
            hover_color=ACCENT_COLOR,
            width=60,
            height=60,
            corner_radius=30,
            command=self.select_file
        )
        next_btn.pack(side="right", padx=10)
        
        # Add utility buttons
        self.add_utility_buttons()
    
    def select_file(self):
        """File selection dialog"""
        self.output_file = filedialog.asksaveasfilename(
            title="Select location to save memory image",
            defaultextension=".raw",
            filetypes=[("RAW files", "*.raw"), ("All Files", "*.*")]
        )
        
        if not self.output_file:
            messagebox.showerror("Error", "No file selected. Please try again.")
            return
        
        self.show_step3()
    
    def show_step3(self):
        """Step 3: Capture with progress"""
        self.clear_container()
        
        # Create a container for better centering
        container = ctk.CTkFrame(self.main_container, fg_color="transparent")
        container.pack(expand=True, fill="both", padx=20, pady=20)
        
        title = ctk.CTkLabel(
            container,
            text="Step 3: Capture Memory",
            font=("Segoe UI", 20, "bold"),
            text_color=PRIMARY_COLOR
        )
        title.pack(pady=20)
        
        # Case info display
        info_frame = ctk.CTkFrame(container, corner_radius=10, fg_color=BACKGROUND_COLOR)
        info_frame.pack(pady=10, padx=20, fill="x")
        
        ctk.CTkLabel(
            info_frame, 
            text=f"Case: {self.user_data['case_name']}",
            font=("Segoe UI", 14),
            text_color=TEXT_COLOR
        ).pack(pady=5)
        
        ctk.CTkLabel(
            info_frame, 
            text=f"Output File: {self.output_file}",
            font=("Segoe UI", 14),
            text_color=TEXT_COLOR
        ).pack(pady=5)
        
        # Progress bar
        self.progress_bar = ctk.CTkProgressBar(
            container,
            mode="determinate",
            width=400,
            fg_color=SECONDARY_COLOR,
            progress_color=PRIMARY_COLOR
        )
        self.progress_bar.pack(pady=20)
        self.progress_bar.set(0)
        
        # Status labels
        self.progress_label = ctk.CTkLabel(
            container,
            text="Ready to capture...",
            font=("Segoe UI", 14),
            text_color=TEXT_COLOR,
            fg_color=SECONDARY_COLOR
        )
        self.progress_label.pack(pady=10)
        
        self.time_left_label = ctk.CTkLabel(
            container,
            text="Estimated time remaining: --",
            font=("Segoe UI", 12),
            text_color=TEXT_COLOR,
            fg_color=SECONDARY_COLOR
        )
        self.time_left_label.pack(pady=5)
        
        # Navigation buttons - circular
        button_frame = ctk.CTkFrame(container)
        button_frame.pack(pady=20)
        
        back_btn = ctk.CTkButton(
            button_frame,
            text="←",
            font=("Segoe UI", 18, "bold"),
            fg_color=PRIMARY_COLOR,
            hover_color=ACCENT_COLOR,
            width=60,
            height=60,
            corner_radius=30,
            command=self.show_step2
        )
        back_btn.pack(side="left", padx=10)
        
        self.capture_btn = ctk.CTkButton(
            button_frame,
            text="⚡",  # Lightning bolt symbol for capture
            font=("Segoe UI", 18, "bold"),
            fg_color=PRIMARY_COLOR,
            hover_color=ACCENT_COLOR,
            width=60,
            height=60,
            corner_radius=30,
            command=self.start_capture
        )
        self.capture_btn.pack(side="right", padx=10)
        
        # Add utility buttons
        self.add_utility_buttons()
    
    def start_capture(self):
        """Start the capture process"""
        if self.capture_active:
            return
        
        # Validate IDs first
        try:
            investigator_id = int(self.user_data["investigator_id"])
            case_id = int(self.user_data["case_id"])
            memory_id = int(self.user_data["memory_id"])
        except ValueError:
            messagebox.showerror("Error", "IDs must be integers.")
            return
        
        errors = validate_unique_ids(investigator_id, case_id, memory_id)
        if errors:
            messagebox.showerror("Error", "\n".join(errors))
            return
        
        # Check if winpmem exists
        winpmem_path = BASE_DIR / "winpmem_mini.exe"
        
        if not winpmem_path.exists():
            messagebox.showerror("Error", "winpmem_mini.exe not found.")
            return
        
        # Prepare for capture
        self.capture_active = True
        self.capture_btn.configure(text="■", command=self.stop_capture)  # Stop symbol
        self.progress_label.configure(text="Capturing memory image...")
        
        # Start capture in a separate thread
        self.capture_thread = threading.Thread(
            target=self.run_capture_process,
            args=(str(winpmem_path), self.output_file),
            daemon=True
        )
        self.capture_thread.start()
    
    def run_capture_process(self, winpmem_path, output_file):
        """Run the actual capture process"""
        command = [winpmem_path, output_file]
        start_time = time.time()
        
        try:
            self.capture_process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
            
            total_steps = 100
            for i in range(total_steps):
                if not self.capture_active:
                    break
                
                time.sleep(0.1)
                progress = (i + 1) / total_steps
                self.progress_bar.set(progress)
                
                # Calculate estimated time remaining
                elapsed_time = time.time() - start_time
                if progress > 0:
                    time_left = (total_steps - (i + 1)) * (elapsed_time / (i + 1))
                    self.time_left_label.configure(text=f"Time left: {time_left:.1f} seconds")
                
                self.root.update_idletasks()
            
            if not self.capture_active:
                # User stopped the capture
                self.capture_process.terminate()
                self.root.after(0, lambda: self.finish_capture(stopped=True))
                return
            
            if not os.path.exists(output_file):
                self.root.after(0, lambda: self.progress_label.configure(text="Capture failed!"))
                self.root.after(0, lambda: messagebox.showerror("Error", "Memory image file was not created."))
                return
            
            # Calculate hash and generate report
            hash_value = calculate_hash(output_file)
            image_size = os.path.getsize(output_file)
            elapsed_time = time.time() - start_time
            
            report_file = generate_report(
                output_file,
                self.user_data["investigator_name"],
                investigator_id,
                self.user_data["case_name"],
                case_id,
                memory_id,
                hash_value,
                image_size,
                elapsed_time,
                self.user_data["report_format"]
            )
            
            # Update used IDs
            used_investigator_ids.add(investigator_id)
            used_case_ids.add(case_id)
            used_memory_ids.add(memory_id)
            
            self.root.after(0, lambda: self.finish_capture(
                success=True,
                output_file=output_file,
                report_file=report_file
            ))
            
        except Exception as e:
            self.root.after(0, lambda: self.progress_label.configure(text="Capture failed!"))
            self.root.after(0, lambda: messagebox.showerror("Error", f"An exception occurred: {str(e)}"))
        finally:
            self.capture_active = False
            self.capture_process = None
    
    def stop_capture(self):
        """Stop the capture process"""
        self.capture_active = False
        self.capture_btn.configure(state="disabled", text="■")
        self.progress_label.configure(text="Stopping capture...")
        
        if self.capture_process:
            self.capture_process.terminate()
    
    def finish_capture(self, stopped=False, success=False, output_file="", report_file=""):
        """Clean up after capture completes or is stopped"""
        self.capture_active = False
        self.capture_btn.configure(
            text="⚡",
            command=self.start_capture,
            state="normal"
        )
        
        if stopped:
            self.progress_label.configure(text="Capture stopped")
            messagebox.showinfo("Stopped", "Capture process was stopped")
        elif success:
            self.progress_label.configure(text="Capture complete!")
            messagebox.showinfo(
                "Success", 
                f"RAM image captured successfully!\nSaved at: {output_file}\nReport saved at: {report_file}"
            )
        else:
            self.progress_label.configure(text="Capture failed!")
            self.time_left_label.configure(text="")

def create_gui():
    global root
    root = ctk.CTk()
    app = MemoryCaptureApp(root)
    root.mainloop()

if __name__ == "__main__":
    create_gui()