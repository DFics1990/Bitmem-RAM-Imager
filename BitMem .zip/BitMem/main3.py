import os
import subprocess
import threading
import customtkinter as ctk
from tkinter import filedialog, messagebox, StringVar
import hashlib
from datetime import datetime
import time
import psutil
from fpdf import FPDF
from PIL import Image
from customtkinter import CTkImage
from pathlib import Path
import json
from docx import Document
import html
import platform

# Global sets to store used IDs
used_investigator_ids = set()
used_case_ids = set()
used_memory_ids = set()

# Configure appearance
ctk.set_appearance_mode("Dark")
ctk.set_default_color_theme("dark-blue")

# Color Theme
DARK_BACKGROUND = "#1E2A38"
DARK_PRIMARY = "#3498DB"
DARK_SECONDARY = "#2C3E50"
DARK_ACCENT = "#2980B9"
DARK_TEXT = "#ECF0F1"

LIGHT_BACKGROUND = "#FFFFFF"
LIGHT_PRIMARY = "#3498DB"
LIGHT_SECONDARY = "#F4F4F4"
LIGHT_ACCENT = "#2980B9"
LIGHT_TEXT = "#2C3E50"

# Global color variables
BACKGROUND_COLOR = DARK_BACKGROUND
PRIMARY_COLOR = DARK_PRIMARY
SECONDARY_COLOR = DARK_SECONDARY
ACCENT_COLOR = DARK_ACCENT
TEXT_COLOR = DARK_TEXT

# Base directory - where the main script is located
BASE_DIR = Path(__file__).parent
ASSETS_DIR = BASE_DIR / "assets"
ICONS_DIR = ASSETS_DIR / "icons"
IMAGES_DIR = ASSETS_DIR / "images"
CONFIG_FILE = BASE_DIR / "bitmem_config.json"

def load_config():
    """Load configuration from file"""
    if CONFIG_FILE.exists():
        try:
            with open(CONFIG_FILE, 'r') as f:
                config = json.load(f)
                # Update appearance mode if it exists in config
                if 'appearance_mode' in config:
                    ctk.set_appearance_mode(config['appearance_mode'])
                    if config['appearance_mode'] == "Light":
                        global BACKGROUND_COLOR, PRIMARY_COLOR, SECONDARY_COLOR, ACCENT_COLOR, TEXT_COLOR
                        BACKGROUND_COLOR = LIGHT_BACKGROUND
                        PRIMARY_COLOR = LIGHT_PRIMARY
                        SECONDARY_COLOR = LIGHT_SECONDARY
                        ACCENT_COLOR = LIGHT_ACCENT
                        TEXT_COLOR = LIGHT_TEXT
                return config
        except Exception as e:
            print(f"Error loading config: {e}")
    return {}

def save_config(config):
    """Save configuration to file"""
    try:
        with open(CONFIG_FILE, 'w') as f:
            json.dump(config, f, indent=4)
    except Exception as e:
        print(f"Error saving config: {e}")

def calculate_hash(file_path, algorithm="sha256"):
    hash_func = hashlib.new(algorithm)
    with open(file_path, "rb") as f:
        for chunk in iter(lambda: f.read(4096), b""):
            hash_func.update(chunk)
    return hash_func.hexdigest()

def generate_report(output_file, investigator_name, investigator_id, case_name, case_id, memory_id, hash_value, image_size, elapsed_time, report_format, hash_algorithm):
    report_file_name = f"Case-{case_name.replace(' ', '_')}_Report.{report_format}"
    report_file = os.path.join(os.path.dirname(output_file), report_file_name)
    
    capture_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    # Format duration with minutes and seconds
    minutes = int(elapsed_time // 60)
    seconds = elapsed_time % 60
    duration_str = f"{minutes} minutes {seconds:.2f} seconds"
    
    # Get additional system information for the report
    ram = psutil.virtual_memory()
    cpu_info = {
        "Physical Cores": psutil.cpu_count(logical=False),
        "Total Cores": psutil.cpu_count(logical=True),
        "Max Frequency": f"{psutil.cpu_freq().max:.2f} MHz"
    }
    disk_info = psutil.disk_usage('/')
    system_info = {
        "System Name": os.environ.get('COMPUTERNAME', 'N/A'),
        "OS": f"{os.name} {platform.system()} {platform.release()}",
        "Architecture": platform.architecture()[0],
        "Python Version": platform.python_version()
    }
    
    report_data = {
        "Investigator Name": investigator_name,
        "Investigator ID": investigator_id,
        "Case Name": case_name,
        "Case ID": case_id,
        "Memory ID": memory_id,
        "Capture Time": capture_time,
        "Image Size": f"{image_size} bytes ({image_size/1024/1024:.2f} MB)",
        "Hash Algorithm": hash_algorithm,
        "Hash Value": hash_value,
        "Image Location": output_file,
        "Capture Duration": duration_str,
        "Memory Details": {
            "Total RAM": f"{ram.total / (1024 ** 3):.2f} GB",
            "Available RAM": f"{ram.available / (1024 ** 3):.2f} GB",
            "RAM Used Percent": f"{ram.percent}%"
        },
        "CPU Information": cpu_info,
        "Disk Information": {
            "Total Disk Space": f"{disk_info.total / (1024 ** 3):.2f} GB",
            "Used Disk Space": f"{disk_info.used / (1024 ** 3):.2f} GB",
            "Free Disk Space": f"{disk_info.free / (1024 ** 3):.2f} GB",
            "Disk Usage Percent": f"{disk_info.percent}%"
        },
        "System Information": system_info,
        "Tool Information": {
            "Tool Name": "BitMem",
            "Capture Method": "WinPMEM",
            "Report Generated": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        }
    }

    if report_format.lower() == "txt":
        with open(report_file, "w") as f:
            f.write("=== MEMORY CAPTURE REPORT ===\n\n")
            for key, value in report_data.items():
                if isinstance(value, dict):
                    f.write(f"\n{key}:\n")
                    for subkey, subvalue in value.items():
                        f.write(f"  {subkey}: {subvalue}\n")
                else:
                    f.write(f"{key}: {value}\n")
    
    elif report_format.lower() == "pdf":
        pdf = FPDF()
        pdf.add_page()
        pdf.set_font("Arial", size=12)
        pdf.cell(0, 10, "MEMORY CAPTURE REPORT", ln=True, align='C')
        pdf.ln(10)
        
        for key, value in report_data.items():
            if isinstance(value, dict):
                pdf.cell(0, 10, f"{key}:", ln=True)
                for subkey, subvalue in value.items():
                    pdf.cell(20)  # Indent
                    pdf.cell(0, 10, f"{subkey}: {subvalue}", ln=True)
            else:
                pdf.cell(0, 10, f"{key}: {value}", ln=True)
        pdf.output(report_file)
    
    elif report_format.lower() == "html":
        with open(report_file, "w") as f:
            f.write("<html><head><title>Memory Capture Report</title>")
            f.write("<style>body {font-family: Arial; margin: 20px;} h1 {color: #3498DB;} table {border-collapse: collapse; width: 100%;} th, td {border: 1px solid #ddd; padding: 8px; text-align: left;} th {background-color: #f2f2f2;} .section {margin-top: 20px; font-weight: bold;}</style>")
            f.write("</head><body>")
            f.write("<h1>Memory Capture Report</h1>")
            
            for key, value in report_data.items():
                if isinstance(value, dict):
                    f.write(f"<div class='section'>{key}</div>")
                    f.write("<table>")
                    for subkey, subvalue in value.items():
                        f.write(f"<tr><td>{subkey}</td><td>{html.escape(str(subvalue))}</td></tr>")
                    f.write("</table>")
                else:
                    f.write(f"<div><strong>{html.escape(key)}</strong>: {html.escape(str(value))}</div>")
            f.write("</body></html>")
    
    elif report_format.lower() == "docx":
        doc = Document()
        doc.add_heading('Memory Capture Report', 0)
        
        for key, value in report_data.items():
            if isinstance(value, dict):
                doc.add_heading(key, level=1)
                table = doc.add_table(rows=1, cols=2)
                hdr_cells = table.rows[0].cells
                hdr_cells[0].text = 'Field'
                hdr_cells[1].text = 'Value'
                for subkey, subvalue in value.items():
                    row_cells = table.add_row().cells
                    row_cells[0].text = subkey
                    row_cells[1].text = str(subvalue)
            else:
                doc.add_paragraph(f"{key}: {value}")
        doc.save(report_file)
    
    elif report_format.lower() == "json":
        with open(report_file, "w") as f:
            json.dump(report_data, f, indent=4)
    
    return report_file

def validate_unique_ids(investigator_id, case_id, memory_id):
    errors = []
    if investigator_id in used_investigator_ids:
        errors.append("Investigator ID is already in use.")
    if case_id in used_case_ids:
        errors.append("Case ID is already in use.")
    if memory_id in used_memory_ids:
        errors.append("Memory ID is already in use.")
    return errors

class MemoryCaptureApp:
    def __init__(self, root):
        self.root = root
        self.root.title("BitMem")
        self.root.geometry("900x700")
        
        # Data storage
        self.user_data = {}
        self.output_file = ""
        self.capture_active = False
        self.capture_thread = None
        self.capture_process = None
        self.capture_start_time = None
        self.capture_bytes_copied = 0
        self.total_memory_size = psutil.virtual_memory().total
        self.hash_algorithm = StringVar(value="sha256")
        self.resume_capture = False
        self.partial_capture_path = None
        self.current_step = 1
        
        # Load config
        self.config = load_config()
        
        # Load all icons
        self.load_icons()
        
        # Set icon
        icon_path = ASSETS_DIR / "newbitmemico.ico"
        if icon_path.exists():
            self.root.iconbitmap(str(icon_path))

        # Background image
        background_image_path = IMAGES_DIR / "newbackback.jpg"
        if background_image_path.exists():
            try:
                self.bg_image = Image.open(background_image_path)
                self.background_photo = CTkImage(light_image=self.bg_image, 
                                               dark_image=self.bg_image,
                                               size=(self.root.winfo_screenwidth(), 
                                                     self.root.winfo_screenheight()))
                self.background_label = ctk.CTkLabel(root, image=self.background_photo, text="")
                self.background_label.place(x=0, y=0, relwidth=1, relheight=1)
            except Exception as e:
                print(f"Error loading background image: {e}")

        # Create main container
        self.main_container = ctk.CTkFrame(root, fg_color=SECONDARY_COLOR, corner_radius=15)
        self.main_container.place(relx=0.5, rely=0.5, anchor="center", relwidth=0.5, relheight=0.9)
        
        # Show welcome screen first
        self.show_welcome_screen()
    
    def load_icons(self):
        """Load all required icons as CTkImage"""
        self.icons = {}
        icon_files = {
            'investigator_name': "invname.png",
            'investigator_id': "invid.png",
            'case_name': "casename.png",
            'case_id': "caseid.png",
            'memory_id': "memoryid.png",
            'report_format': "report format.png",
            'hash': "hash.png"
        }
        
        for key, filename in icon_files.items():
            icon_path = ICONS_DIR / filename
            if icon_path.exists():
                try:
                    img = Image.open(icon_path)
                    img = img.resize((20, 20), Image.Resampling.LANCZOS)
                    self.icons[key] = CTkImage(light_image=img, dark_image=img, size=(20, 20))
                except Exception as e:
                    print(f"Error loading {key} icon: {e}")
    
    def clear_container(self):
        """Clear all widgets from the main container"""
        for widget in self.main_container.winfo_children():
            widget.destroy()
    
    def show_welcome_screen(self):
        """Initial welcome screen"""
        self.clear_container()
        
        container = ctk.CTkFrame(self.main_container, fg_color="transparent")
        container.pack(expand=True, fill="both", padx=20, pady=20)
        
        title_frame = ctk.CTkFrame(container, fg_color="transparent")
        title_frame.pack(pady=(60, 20))  # Increased top padding to move text down
        
        # Welcome text
        self.welcome_label = ctk.CTkLabel(
            title_frame,
            text="Welcome!",
            font=("Segoe UI", 14),
            text_color=TEXT_COLOR
        )
        self.welcome_label.pack()
        
        # Main title - moved down with increased pady
        self.line1 = ctk.CTkLabel(
            title_frame,
            text="Capture RAM Image with",
            font=("Segoe UI", 24, "bold"),
            text_color=PRIMARY_COLOR
        )
        self.line1.pack()
        
        self.line2 = ctk.CTkLabel(
            title_frame,
            text="BitMem",
            font=("Segoe UI", 36, "bold"),
            text_color=PRIMARY_COLOR
        )
        self.line2.pack(pady=5)
        
        self.start_btn = ctk.CTkButton(
            container,
            text="Start",
            font=("Segoe UI", 18, "bold"),
            fg_color=PRIMARY_COLOR,
            hover_color=ACCENT_COLOR,
            width=120,
            height=120,
            corner_radius=60,
            command=self.show_step1
        )
        self.start_btn.pack(pady=40)
        
        # Thank you message below the button
        self.thanks_label = ctk.CTkLabel(
            container,
            text="Thanks for using BitMem!",
            font=("Segoe UI", 14),
            text_color=TEXT_COLOR
        )
        self.thanks_label.pack()
        
        self.add_utility_buttons()
    
    def add_utility_buttons(self):
        """Add system info and mode switch buttons"""
        self.sys_info_btn = ctk.CTkButton(
            self.main_container, 
            text="ℹ",
            font=("Segoe UI", 16, "bold"),
            fg_color=PRIMARY_COLOR, 
            hover_color=ACCENT_COLOR,
            width=40,
            height=40,
            corner_radius=20,
            command=self.show_system_info
        )
        self.sys_info_btn.place(relx=0.05, rely=0.05, anchor="nw")
        
        self.mode_btn = ctk.CTkButton(
            self.main_container, 
            text="☀" if ctk.get_appearance_mode() == "Dark" else "🌙",
            font=("Segoe UI", 16, "bold"),
            fg_color=PRIMARY_COLOR, 
            hover_color=ACCENT_COLOR,
            width=40,
            height=40,
            corner_radius=20,
            command=self.toggle_mode
        )
        self.mode_btn.place(relx=0.95, rely=0.05, anchor="ne")
    
    def show_system_info(self):
        """Show system information"""
        ram = psutil.virtual_memory()
        cpu_usage = psutil.cpu_percent(interval=1)
        disk_usage = psutil.disk_usage('/')
        uptime = time.time() - psutil.boot_time()
        uptime_hours = int(uptime // 3600)
        uptime_minutes = int((uptime % 3600) // 60)
        
        info = (
            f"Total RAM: {ram.total / (1024 ** 3):.2f} GB\n"
            f"Used RAM: {ram.used / (1024 ** 3):.2f} GB\n"
            f"CPU Usage: {cpu_usage}%\n"
            f"Disk Usage: {disk_usage.percent}%\n"
            f"System Uptime: {uptime_hours}h {uptime_minutes}m"
        )
        messagebox.showinfo("System Information", info)
    
    def toggle_mode(self):
        """Toggle between dark/light mode without changing windows"""
        global BACKGROUND_COLOR, PRIMARY_COLOR, SECONDARY_COLOR, ACCENT_COLOR, TEXT_COLOR
        current_mode = ctk.get_appearance_mode()
        if current_mode == "Dark":
            new_mode = "Light"
            BACKGROUND_COLOR = LIGHT_BACKGROUND
            PRIMARY_COLOR = LIGHT_PRIMARY
            SECONDARY_COLOR = LIGHT_SECONDARY
            ACCENT_COLOR = LIGHT_ACCENT
            TEXT_COLOR = LIGHT_TEXT
            self.mode_btn.configure(text="🌙")
        else:
            new_mode = "Dark"
            BACKGROUND_COLOR = DARK_BACKGROUND
            PRIMARY_COLOR = DARK_PRIMARY
            SECONDARY_COLOR = DARK_SECONDARY
            ACCENT_COLOR = DARK_ACCENT
            TEXT_COLOR = DARK_TEXT
            self.mode_btn.configure(text="☀")
        
        ctk.set_appearance_mode(new_mode)
        self.update_colors()
        
        # Save the mode preference
        self.config['appearance_mode'] = new_mode
        save_config(self.config)
    
    def update_colors(self):
        """Update colors for all widgets in current window"""
        # Update main container
        self.main_container.configure(fg_color=SECONDARY_COLOR)
        
        # Update utility buttons
        self.sys_info_btn.configure(fg_color=PRIMARY_COLOR, hover_color=ACCENT_COLOR)
        self.mode_btn.configure(fg_color=PRIMARY_COLOR, hover_color=ACCENT_COLOR)
        
        # Get current step and update its specific widgets
        if hasattr(self, 'current_step'):
            if self.current_step == 0:  # Welcome screen
                self.update_welcome_colors()
            elif self.current_step == 1:
                self.update_step1_colors()
            elif self.current_step == 2:
                self.update_step2_colors()
            elif self.current_step == 3:
                self.update_step3_colors()
    
    def update_welcome_colors(self):
        """Update colors for welcome screen widgets"""
        if hasattr(self, 'welcome_label'):
            self.welcome_label.configure(text_color=TEXT_COLOR)
        if hasattr(self, 'line1'):
            self.line1.configure(text_color=PRIMARY_COLOR)
        if hasattr(self, 'line2'):
            self.line2.configure(text_color=PRIMARY_COLOR)
        if hasattr(self, 'start_btn'):
            self.start_btn.configure(fg_color=PRIMARY_COLOR, hover_color=ACCENT_COLOR)
        if hasattr(self, 'thanks_label'):
            self.thanks_label.configure(text_color=TEXT_COLOR)
    
    def update_step1_colors(self):
        """Update colors for step 1 widgets"""
        if hasattr(self, 'investigator_name_entry'):
            # Update all entry fields if they exist
            entries = []
            if hasattr(self, 'investigator_name_entry'):
                entries.append(self.investigator_name_entry)
            if hasattr(self, 'investigator_id_entry'):
                entries.append(self.investigator_id_entry)
            if hasattr(self, 'case_name_entry'):
                entries.append(self.case_name_entry)
            if hasattr(self, 'case_id_entry'):
                entries.append(self.case_id_entry)
            if hasattr(self, 'memory_id_entry'):
                entries.append(self.memory_id_entry)
            
            for entry in entries:
                try:
                    entry.configure(fg_color=SECONDARY_COLOR, text_color=TEXT_COLOR)
                except:
                    pass
            
            # Update option menus if they exist
            if hasattr(self, 'report_format_menu'):
                try:
                    self.report_format_menu.configure(fg_color=SECONDARY_COLOR, text_color=TEXT_COLOR)
                except:
                    pass
            if hasattr(self, 'hash_menu'):
                try:
                    self.hash_menu.configure(fg_color=SECONDARY_COLOR, text_color=TEXT_COLOR)
                except:
                    pass
            
            # Update input frame background if it exists
            if hasattr(self, 'input_frame'):
                try:
                    self.input_frame.configure(fg_color=BACKGROUND_COLOR)
                except:
                    pass
    
    def update_step2_colors(self):
        """Update colors for step 2 widgets"""
        if hasattr(self, 'info_frame'):
            try:
                self.info_frame.configure(fg_color=BACKGROUND_COLOR)
                for label in self.info_frame.winfo_children():
                    if isinstance(label, ctk.CTkLabel):
                        label.configure(text_color=TEXT_COLOR)
            except:
                pass
        
        if hasattr(self, 'selected_file_label'):
            try:
                self.selected_file_label.configure(text_color=TEXT_COLOR)
            except:
                pass
    
    def update_step3_colors(self):
        """Update colors for step 3 widgets"""
        if hasattr(self, 'info_frame'):
            try:
                self.info_frame.configure(fg_color=BACKGROUND_COLOR)
                for label in self.info_frame.winfo_children():
                    if isinstance(label, ctk.CTkLabel):
                        label.configure(text_color=TEXT_COLOR)
            except:
                pass
        
        if hasattr(self, 'progress_label'):
            try:
                self.progress_label.configure(text_color=TEXT_COLOR)
            except:
                pass
        
        if hasattr(self, 'time_left_label'):
            try:
                self.time_left_label.configure(text_color=TEXT_COLOR)
            except:
                pass
    
    def create_label_with_icon(self, parent, text, icon_key):
        """Create a label with an icon next to it"""
        frame = ctk.CTkFrame(parent, fg_color="transparent")
        
        if icon_key in self.icons:
            icon_label = ctk.CTkLabel(frame, image=self.icons[icon_key], text="")
            icon_label.pack(side="left", padx=(0, 5))
        
        label = ctk.CTkLabel(frame, text=text, font=("Segoe UI", 14), text_color=TEXT_COLOR)
        label.pack(side="left")
        
        return frame
    
    def validate_ids(self):
        """Validate ID fields before proceeding to next step"""
        try:
            investigator_id = int(self.investigator_id_entry.get())
            case_id = int(self.case_id_entry.get())
            memory_id = int(self.memory_id_entry.get())
        except ValueError:
            messagebox.showerror("Error", "IDs must be integers.")
            return False
        
        errors = validate_unique_ids(investigator_id, case_id, memory_id)
        if errors:
            messagebox.showerror("Error", "\n".join(errors))
            return False
        
        return True
    
    def show_step1(self):
        """Step 1: User information input"""
        self.current_step = 1
        self.clear_container()
        
        container = ctk.CTkFrame(self.main_container, fg_color="transparent")
        container.pack(expand=True, fill="both", padx=20, pady=20)
        
        title = ctk.CTkLabel(
            container,
            text="Step 1: Enter Case Details",
            font=("Segoe UI", 20, "bold"),
            text_color=PRIMARY_COLOR
        )
        title.pack(pady=20)
        
        self.input_frame = ctk.CTkFrame(container, corner_radius=10, fg_color=BACKGROUND_COLOR)
        self.input_frame.pack(pady=10, padx=20, fill="both", expand=True)
        
        self.input_frame.grid_columnconfigure(0, weight=1)
        self.input_frame.grid_columnconfigure(1, weight=1)

        # Investigator Details
        self.create_label_with_icon(self.input_frame, "Investigator Name:", "investigator_name").grid(row=0, column=0, padx=10, pady=10, sticky="e")
        self.investigator_name_entry = ctk.CTkEntry(self.input_frame, font=("Segoe UI", 14), fg_color=SECONDARY_COLOR, text_color=TEXT_COLOR)
        self.investigator_name_entry.grid(row=0, column=1, padx=10, pady=10, sticky="w")
        if 'investigator_name' in self.user_data:
            self.investigator_name_entry.insert(0, self.user_data['investigator_name'])
        self.investigator_name_entry.focus_set()

        self.create_label_with_icon(self.input_frame, "Investigator ID:", "investigator_id").grid(row=1, column=0, padx=10, pady=10, sticky="e")
        self.investigator_id_entry = ctk.CTkEntry(self.input_frame, font=("Segoe UI", 14), fg_color=SECONDARY_COLOR, text_color=TEXT_COLOR)
        self.investigator_id_entry.grid(row=1, column=1, padx=10, pady=10, sticky="w")
        if 'investigator_id' in self.user_data:
            self.investigator_id_entry.insert(0, self.user_data['investigator_id'])

        # Case Details
        self.create_label_with_icon(self.input_frame, "Case Name:", "case_name").grid(row=2, column=0, padx=10, pady=10, sticky="e")
        self.case_name_entry = ctk.CTkEntry(self.input_frame, font=("Segoe UI", 14), fg_color=SECONDARY_COLOR, text_color=TEXT_COLOR)
        self.case_name_entry.grid(row=2, column=1, padx=10, pady=10, sticky="w")
        if 'case_name' in self.user_data:
            self.case_name_entry.insert(0, self.user_data['case_name'])

        self.create_label_with_icon(self.input_frame, "Case ID:", "case_id").grid(row=3, column=0, padx=10, pady=10, sticky="e")
        self.case_id_entry = ctk.CTkEntry(self.input_frame, font=("Segoe UI", 14), fg_color=SECONDARY_COLOR, text_color=TEXT_COLOR)
        self.case_id_entry.grid(row=3, column=1, padx=10, pady=10, sticky="w")
        if 'case_id' in self.user_data:
            self.case_id_entry.insert(0, self.user_data['case_id'])

        # Memory ID
        self.create_label_with_icon(self.input_frame, "Memory ID:", "memory_id").grid(row=4, column=0, padx=10, pady=10, sticky="e")
        self.memory_id_entry = ctk.CTkEntry(self.input_frame, font=("Segoe UI", 14), fg_color=SECONDARY_COLOR, text_color=TEXT_COLOR)
        self.memory_id_entry.grid(row=4, column=1, padx=10, pady=10, sticky="w")
        if 'memory_id' in self.user_data:
            self.memory_id_entry.insert(0, self.user_data['memory_id'])

        # Report Format
        self.create_label_with_icon(self.input_frame, "Report Format:", "report_format").grid(row=5, column=0, padx=10, pady=10, sticky="e")
        self.report_format_var = StringVar(value="pdf")
        if 'report_format' in self.user_data:
            self.report_format_var.set(self.user_data['report_format'])
        self.report_format_menu = ctk.CTkOptionMenu(
            self.input_frame,
            variable=self.report_format_var,
            values=["txt", "pdf", "html", "docx", "json"],
            font=("Segoe UI", 14),
            fg_color=SECONDARY_COLOR,
            text_color=TEXT_COLOR
        )
        self.report_format_menu.grid(row=5, column=1, padx=10, pady=10, sticky="w")

        # Hash Algorithm
        self.create_label_with_icon(self.input_frame, "Hash Algorithm:", "hash").grid(row=6, column=0, padx=10, pady=10, sticky="e")
        self.hash_algorithm = StringVar(value="sha256")
        if 'hash_algorithm' in self.user_data:
            self.hash_algorithm.set(self.user_data['hash_algorithm'])
        self.hash_menu = ctk.CTkOptionMenu(
            self.input_frame, 
            variable=self.hash_algorithm,
            values=["md5", "sha1", "sha256", "sha512"],
            font=("Segoe UI", 14),
            fg_color=SECONDARY_COLOR,
            text_color=TEXT_COLOR
        )
        self.hash_menu.grid(row=6, column=1, padx=10, pady=10, sticky="w")
        
        # Navigation buttons with blue circles
        button_frame = ctk.CTkFrame(container, fg_color="transparent")
        button_frame.pack(pady=20)
        
        back_btn = ctk.CTkButton(
            button_frame,
            text="←",
            font=("Segoe UI", 18, "bold"),
            fg_color=PRIMARY_COLOR,
            hover_color=ACCENT_COLOR,
            width=60,
            height=60,
            corner_radius=30,
            command=self.show_welcome_screen
        )
        back_btn.pack(side="left", padx=10)
        
        next_btn = ctk.CTkButton(
            button_frame,
            text="→",
            font=("Segoe UI", 18, "bold"),
            fg_color=PRIMARY_COLOR,
            hover_color=ACCENT_COLOR,
            width=60,
            height=60,
            corner_radius=30,
            command=self.validate_step1
        )
        next_btn.pack(side="right", padx=10)
        
        # Setup Enter key navigation between fields
        self.investigator_name_entry.bind('<Return>', lambda e: self.investigator_id_entry.focus())
        self.investigator_id_entry.bind('<Return>', lambda e: self.case_name_entry.focus())
        self.case_name_entry.bind('<Return>', lambda e: self.case_id_entry.focus())
        self.case_id_entry.bind('<Return>', lambda e: self.memory_id_entry.focus())
        self.memory_id_entry.bind('<Return>', lambda e: self.report_format_menu.focus())
        self.report_format_menu.bind('<Return>', lambda e: self.hash_menu.focus())
        self.hash_menu.bind('<Return>', lambda e: self.validate_step1())
        
        self.add_utility_buttons()
    
    def validate_step1(self):
        """Validate step 1 inputs before proceeding"""
        if not all([
            self.investigator_name_entry.get(),
            self.investigator_id_entry.get(),
            self.case_name_entry.get(),
            self.case_id_entry.get(),
            self.memory_id_entry.get()
        ]):
            messagebox.showerror("Error", "Please fill all fields")
            return
        
        # Validate IDs before proceeding
        if not self.validate_ids():
            return
        
        self.user_data = {
            "investigator_name": self.investigator_name_entry.get(),
            "investigator_id": self.investigator_id_entry.get(),
            "case_name": self.case_name_entry.get(),
            "case_id": self.case_id_entry.get(),
            "memory_id": self.memory_id_entry.get(),
            "report_format": self.report_format_var.get(),
            "hash_algorithm": self.hash_algorithm.get()
        }
        
        self.show_step2()
    
    def show_step2(self):
        """Step 2: File selection"""
        self.current_step = 2
        self.clear_container()
        
        container = ctk.CTkFrame(self.main_container, fg_color="transparent")
        container.pack(expand=True, fill="both", padx=20, pady=20)
        
        title = ctk.CTkLabel(
            container,
            text="Step 2: Select Output Location",
            font=("Segoe UI", 20, "bold"),
            text_color=PRIMARY_COLOR
        )
        title.pack(pady=20)
        
        self.info_frame = ctk.CTkFrame(container, corner_radius=10, fg_color=BACKGROUND_COLOR)
        self.info_frame.pack(pady=10, padx=20, fill="x")
        
        ctk.CTkLabel(
            self.info_frame, 
            text=f"Investigator: {self.user_data['investigator_name']} (ID: {self.user_data['investigator_id']})",
            font=("Segoe UI", 14),
            text_color=TEXT_COLOR
        ).pack(pady=5)
        
        ctk.CTkLabel(
            self.info_frame, 
            text=f"Case: {self.user_data['case_name']} (ID: {self.user_data['case_id']})",
            font=("Segoe UI", 14),
            text_color=TEXT_COLOR
        ).pack(pady=5)
        
        select_btn_frame = ctk.CTkFrame(container, fg_color="transparent")
        select_btn_frame.pack(pady=20)
        
        select_btn = ctk.CTkButton(
            select_btn_frame,
            text="📁 Select Output File",
            font=("Segoe UI", 14, "bold"),
            fg_color=PRIMARY_COLOR,
            hover_color=ACCENT_COLOR,
            command=self.select_file
        )
        select_btn.pack(pady=10)
        
        # Display selected file path
        self.selected_file_label = ctk.CTkLabel(
            select_btn_frame,
            text="No file selected" if not self.output_file else f"Selected: {self.output_file}",
            font=("Segoe UI", 12),
            text_color=TEXT_COLOR,
            wraplength=400
        )
        self.selected_file_label.pack(pady=5)
        
        button_frame = ctk.CTkFrame(container, fg_color="transparent")
        button_frame.pack(pady=20)
        
        back_btn = ctk.CTkButton(
            button_frame,
            text="←",
            font=("Segoe UI", 18, "bold"),
            fg_color=PRIMARY_COLOR,
            hover_color=ACCENT_COLOR,
            width=60,
            height=60,
            corner_radius=30,
            command=self.show_step1
        )
        back_btn.pack(side="left", padx=10)
        
        self.next_btn_step2 = ctk.CTkButton(
            button_frame,
            text="→",
            font=("Segoe UI", 18, "bold"),
            fg_color=PRIMARY_COLOR,
            hover_color=ACCENT_COLOR,
            width=60,
            height=60,
            corner_radius=30,
            state="disabled" if not self.output_file else "normal",
            command=self.show_step3
        )
        self.next_btn_step2.pack(side="right", padx=10)
        
        # Bind Enter key to select_file
        self.root.bind('<Return>', lambda event: self.select_file())
        
        self.add_utility_buttons()
    
    def select_file(self):
        """File selection dialog"""
        file_path = filedialog.asksaveasfilename(
            title="Select location to save memory image",
            defaultextension=".raw",
            filetypes=[("RAW files", "*.raw"), ("All Files", "*.*")]
        )
        
        if file_path:
            self.output_file = file_path
            self.selected_file_label.configure(text=f"Selected: {self.output_file}")
            self.next_btn_step2.configure(state="normal")
            # Change Enter key binding to proceed to next step
            self.root.unbind('<Return>')
            self.root.bind('<Return>', lambda event: self.show_step3())
        else:
            messagebox.showerror("Error", "No file selected. Please try again.")
        
    def show_step3(self):
        """Step 3: Capture with progress"""
        self.current_step = 3
        self.clear_container()
        
        container = ctk.CTkFrame(self.main_container, fg_color="transparent")
        container.pack(expand=True, fill="both", padx=20, pady=20)
        
        title = ctk.CTkLabel(
            container,
            text="Step 3: Capture Memory",
            font=("Segoe UI", 20, "bold"),
            text_color=PRIMARY_COLOR
        )
        title.pack(pady=20)
        
        self.info_frame = ctk.CTkFrame(container, corner_radius=10, fg_color=BACKGROUND_COLOR)
        self.info_frame.pack(pady=10, padx=20, fill="x")
        
        ctk.CTkLabel(
            self.info_frame, 
            text=f"Case: {self.user_data['case_name']}",
            font=("Segoe UI", 14),
            text_color=TEXT_COLOR
        ).pack(pady=5)
        
        ctk.CTkLabel(
            self.info_frame, 
            text=f"Output File: {self.output_file}",
            font=("Segoe UI", 14),
            text_color=TEXT_COLOR
        ).pack(pady=5)
        
        # Progress container
        progress_container = ctk.CTkFrame(container, fg_color="transparent")
        progress_container.pack(pady=40, fill="x", expand=True)
        
        self.progress_bar = ctk.CTkProgressBar(
            progress_container,
            mode="determinate",
            width=500,
            height=30,
            fg_color=SECONDARY_COLOR,
            progress_color=PRIMARY_COLOR
        )
        self.progress_bar.pack(pady=20)
        self.progress_bar.set(0)
        
        self.progress_label = ctk.CTkLabel(
            progress_container,
            text="Ready to capture... 0%",
            font=("Segoe UI", 16),
            text_color=TEXT_COLOR
        )
        self.progress_label.pack(pady=10)
        
        self.time_left_label = ctk.CTkLabel(
            progress_container,
            text="Estimated time remaining: --",
            font=("Segoe UI", 14),
            text_color=TEXT_COLOR
        )
        self.time_left_label.pack(pady=5)
        
        # Navigation buttons with blue circles
        button_frame = ctk.CTkFrame(container, fg_color="transparent")
        button_frame.pack(pady=20)
        
        back_btn = ctk.CTkButton(
            button_frame,
            text="←",
            font=("Segoe UI", 18, "bold"),
            fg_color=PRIMARY_COLOR,
            hover_color=ACCENT_COLOR,
            width=60,
            height=60,
            corner_radius=30,
            command=self.show_step2
        )
        back_btn.pack(side="left", padx=10)
        
        self.capture_btn = ctk.CTkButton(
            button_frame,
            text="⚡",
            font=("Segoe UI", 18, "bold"),
            fg_color=PRIMARY_COLOR,
            hover_color=ACCENT_COLOR,
            width=60,
            height=60,
            corner_radius=30,
            command=self.start_capture
        )
        self.capture_btn.pack(side="right", padx=10)
        
        self.root.bind('<Return>', lambda event: self.start_capture())
        self.add_utility_buttons()

    def start_capture(self):
        """Start or resume capture"""
        if self.resume_capture and self.partial_capture_path:
            resume_msg = f"Resume previous capture?\nPartial file: {os.path.getsize(self.partial_capture_path)/1024/1024:.2f} MB"
            if messagebox.askyesno("Resume Capture", resume_msg):
                self.output_file = self.partial_capture_path
                self.capture_bytes_copied = os.path.getsize(self.output_file)
            else:
                self.resume_capture = False
                self.partial_capture_path = None
        
        if not self.resume_capture:
            self.capture_bytes_copied = 0
            self.capture_start_time = time.time()
            self.total_memory_size = psutil.virtual_memory().total
        
        self.capture_active = True
        self.capture_btn.configure(text="■", command=self.stop_capture)
        self.progress_label.configure(text="Initializing capture... 0%")
        
        self.capture_thread = threading.Thread(
            target=self.run_capture_process,
            args=(str(BASE_DIR / "winpmem_mini.exe"), self.output_file),
            daemon=True
        )
        self.capture_thread.start()

    def run_capture_process(self, winpmem_path, output_file):
        """Run the actual capture process with proper completion detection"""
        command = [winpmem_path, output_file]
        start_time = time.time()
        last_update_time = start_time
        last_size = 0
        
        mem_info = psutil.virtual_memory()
        self.total_memory_size = mem_info.total
        self.capture_start_time = start_time
        
        try:
            # Start the process with a timeout
            self.capture_process = subprocess.Popen(
                command, 
                stdout=subprocess.PIPE, 
                stderr=subprocess.PIPE
            )
            
            # Initial delay to let the process start
            time.sleep(1)
            
            while self.capture_active:
                current_time = time.time()
                
                # Check if process has completed
                if self.capture_process.poll() is not None:
                    break
                
                # Get current file size
                try:
                    current_size = os.path.getsize(output_file)
                except FileNotFoundError:
                    current_size = 0
                
                # Only update if size changed or it's been 0.5 seconds
                if current_size != last_size or current_time - last_update_time >= 0.5:
                    progress = min((self.capture_bytes_copied + current_size) / self.total_memory_size, 1.0)
                    
                    # Update UI
                    self.progress_label.configure(text=f"Capturing... {progress*100:.1f}%")
                    self.progress_bar.set(progress)
                    
                    # Calculate transfer rate and time remaining
                    elapsed = current_time - start_time
                    if progress > 0.01 and elapsed > 0:
                        transfer_rate = (current_size - last_size) / (1024 * 1024 * (current_time - last_update_time)) if current_time > last_update_time else 0
                        estimated_total = elapsed / progress
                        remaining = max(estimated_total - elapsed, 0)
                        self.time_left_label.configure(text=f"Time left: {remaining:.1f} sec | Speed: {transfer_rate:.1f} MB/s")
                    
                    last_size = current_size
                    last_update_time = current_time
                
                time.sleep(0.1)
            
            # Process completed or was stopped
            if not self.capture_active:
                # User stopped the capture
                self.root.after(0, lambda: self.finish_capture(stopped=True))
                return
            
            # Check if capture completed successfully
            if os.path.exists(output_file):
                final_size = os.path.getsize(output_file)
                if final_size < self.total_memory_size * 0.95:  # Allow 5% tolerance
                    self.root.after(0, lambda: self.progress_label.configure(text="Capture incomplete!"))
                    self.root.after(0, lambda: messagebox.showerror("Error", 
                        f"Capture did not complete (only {final_size/1024/1024:.1f} MB of {self.total_memory_size/1024/1024:.1f} MB captured)"))
                    return
            
            # Calculate hash and generate report
            hash_value = calculate_hash(output_file, self.user_data["hash_algorithm"])
            image_size = os.path.getsize(output_file)
            elapsed_time = time.time() - start_time
            
            report_file = generate_report(
                output_file,
                self.user_data["investigator_name"],
                int(self.user_data["investigator_id"]),
                self.user_data["case_name"],
                int(self.user_data["case_id"]),
                int(self.user_data["memory_id"]),
                hash_value,
                image_size,
                elapsed_time,
                self.user_data["report_format"],
                self.user_data["hash_algorithm"]
            )
            
            # Mark IDs as used
            used_investigator_ids.add(int(self.user_data["investigator_id"]))
            used_case_ids.add(int(self.user_data["case_id"]))
            used_memory_ids.add(int(self.user_data["memory_id"]))
            
            self.root.after(0, lambda: self.finish_capture(
                success=True,
                output_file=output_file,
                report_file=report_file
            ))
            
        except Exception as e:
            self.root.after(0, lambda: self.progress_label.configure(text=f"Error: {str(e)}"))
            self.root.after(0, lambda: messagebox.showerror("Error", f"An exception occurred: {str(e)}"))
        finally:
            self.capture_active = False
            if hasattr(self, 'capture_process') and self.capture_process:
                try:
                    self.capture_process.terminate()
                except:
                    pass
            
            
    def stop_capture(self):
        """Stop capture and save partial progress"""
        self.capture_active = False
        if self.capture_process:
            self.capture_process.terminate()
        
        if os.path.exists(self.output_file):
            file_size = os.path.getsize(self.output_file)
            if file_size > 0 and file_size < self.total_memory_size:
                if messagebox.askyesno("Partial Capture", "Save partial capture for resuming later?"):
                    self.partial_capture_path = self.output_file
                    self.resume_capture = True
                    self.capture_bytes_copied = file_size
    
    def finish_capture(self, stopped=False, success=False, output_file="", report_file=""):
        """Clean up after capture completes or is stopped"""
        self.capture_active = False
        self.capture_btn.configure(
            text="⚡",
            command=self.start_capture,
            state="normal"
        )
        
        if stopped:
            self.progress_label.configure(text="Capture stopped")
            messagebox.showinfo("Stopped", "Capture process was stopped")
        elif success:
            self.progress_label.configure(text="Capture complete! 100%")
            self.progress_bar.set(1)
            messagebox.showinfo(
                "Success", 
                f"RAM image captured successfully!\nSaved at: {output_file}\nReport saved at: {report_file}"
            )
            self.resume_capture = False
            self.partial_capture_path = None
        else:
            self.progress_label.configure(text="Capture failed!")
            self.time_left_label.configure(text="")

def create_gui():
    root = ctk.CTk()
    app = MemoryCaptureApp(root)
    root.mainloop()

if __name__ == "__main__":
    create_gui()