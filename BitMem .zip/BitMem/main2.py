import os
import subprocess
import threading
import customtkinter as ctk
from tkinter import filedialog, messagebox, StringVar
import hashlib
from datetime import datetime
import time
import psutil
from fpdf import FPDF
from PIL import Image
from customtkinter import CTkImage
from pathlib import Path
import json
from docx import Document
import html

# Global sets to store used IDs
used_investigator_ids = set()
used_case_ids = set()
used_memory_ids = set()

# Configuration file path
CONFIG_FILE = Path(__file__).parent / "bitmem_config.json"

# Load saved configuration if exists
def load_config():
    if CONFIG_FILE.exists():
        try:
            with open(CONFIG_FILE, 'r') as f:
                return json.load(f)
        except:
            return {}
    return {}

# Save configuration
def save_config(config):
    with open(CONFIG_FILE, 'w') as f:
        json.dump(config, f)

# Initial config
config = load_config()

# Configure appearance
appearance_mode = config.get('appearance_mode', 'Dark')
ctk.set_appearance_mode(appearance_mode)
ctk.set_default_color_theme("dark-blue")

# Color Theme
DARK_BACKGROUND = "#1E2A38"
DARK_PRIMARY = "#3498DB"
DARK_SECONDARY = "#2C3E50"
DARK_ACCENT = "#2980B9"
DARK_TEXT = "#ECF0F1"

LIGHT_BACKGROUND = "#FFFFFF"
LIGHT_PRIMARY = "#3498DB"
LIGHT_SECONDARY = "#BDC3C7"
LIGHT_ACCENT = "#2980B9"
LIGHT_TEXT = "#2C3E50"

# Global color variables
BACKGROUND_COLOR = DARK_BACKGROUND if appearance_mode == "Dark" else LIGHT_BACKGROUND
PRIMARY_COLOR = DARK_PRIMARY if appearance_mode == "Dark" else LIGHT_PRIMARY
SECONDARY_COLOR = DARK_SECONDARY if appearance_mode == "Dark" else LIGHT_SECONDARY
ACCENT_COLOR = DARK_ACCENT if appearance_mode == "Dark" else LIGHT_ACCENT
TEXT_COLOR = DARK_TEXT if appearance_mode == "Dark" else LIGHT_TEXT

# Base directory - where the main script is located
BASE_DIR = Path(__file__).parent
ASSETS_DIR = BASE_DIR / "assets"
ICONS_DIR = ASSETS_DIR / "icons"
IMAGES_DIR = ASSETS_DIR / "images"

def calculate_hash(file_path, algorithm="sha256"):
    hash_func = hashlib.new(algorithm)
    with open(file_path, "rb") as f:
        for chunk in iter(lambda: f.read(4096), b""):
            hash_func.update(chunk)
    return hash_func.hexdigest()

def generate_report(output_file, investigator_name, investigator_id, case_name, case_id, memory_id, hash_value, image_size, elapsed_time, report_format, hash_algorithm):
    report_file_name = f"Case-{case_name.replace(' ', '_')}_Report.{report_format}"
    report_file = os.path.join(os.path.dirname(output_file), report_file_name)
    
    capture_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    report_data = {
        "Investigator Name": investigator_name,
        "Investigator ID": investigator_id,
        "Case Name": case_name,
        "Case ID": case_id,
        "Memory ID": memory_id,
        "Capture Time": capture_time,
        "Image Size": f"{image_size} bytes",
        "Hash Algorithm": hash_algorithm,
        "Hash Value": hash_value,
        "Image Location": output_file,
        "Capture Duration": f"{elapsed_time:.2f} seconds"
    }

    if report_format.lower() == "txt":
        with open(report_file, "w") as f:
            for key, value in report_data.items():
                f.write(f"{key}: {value}\n")
    
    elif report_format.lower() == "pdf":
        pdf = FPDF()
        pdf.add_page()
        pdf.set_font("Arial", size=12)
        for key, value in report_data.items():
            pdf.cell(0, 10, f"{key}: {value}", ln=True)
        pdf.output(report_file)
    
    elif report_format.lower() == "html":
        with open(report_file, "w") as f:
            f.write("<html><head><title>Memory Capture Report</title></head><body>")
            f.write("<h1>Memory Capture Report</h1>")
            f.write("<table border='1'>")
            for key, value in report_data.items():
                f.write(f"<tr><td><strong>{html.escape(key)}</strong></td><td>{html.escape(str(value))}</td></tr>")
            f.write("</table></body></html>")
    
    elif report_format.lower() == "docx":
        doc = Document()
        doc.add_heading('Memory Capture Report', 0)
        table = doc.add_table(rows=1, cols=2)
        hdr_cells = table.rows[0].cells
        hdr_cells[0].text = 'Field'
        hdr_cells[1].text = 'Value'
        for key, value in report_data.items():
            row_cells = table.add_row().cells
            row_cells[0].text = key
            row_cells[1].text = str(value)
        doc.save(report_file)
    
    elif report_format.lower() == "json":
        with open(report_file, "w") as f:
            json.dump(report_data, f, indent=4)
    
    return report_file

def validate_unique_ids(investigator_id, case_id, memory_id):
    errors = []
    if investigator_id in used_investigator_ids:
        errors.append("Investigator ID is already in use.")
    if case_id in used_case_ids:
        errors.append("Case ID is already in use.")
    if memory_id in used_memory_ids:
        errors.append("Memory ID is already in use.")
    return errors

class MemoryCaptureApp:
    def __init__(self, root):
        self.root = root
        self.root.title("BitMem")
        self.root.geometry("900x700")
        
        # Data storage
        self.user_data = {}
        self.output_file = ""
        self.capture_active = False
        self.capture_thread = None
        self.capture_process = None
        self.capture_start_time = None
        self.capture_bytes_copied = 0
        self.total_memory_size = psutil.virtual_memory().total
        self.hash_algorithm = StringVar(value="sha256")
        self.resume_capture = False
        self.partial_capture_path = None
        
        # Load all icons and logo
        self.load_icons()
        
        # Set window icon
        icon_path = ASSETS_DIR / "newbitmemico.ico"
        if icon_path.exists():
            self.root.iconbitmap(str(icon_path))

        # Create main container with solid background
        self.main_container = ctk.CTkFrame(root, fg_color=BACKGROUND_COLOR)
        self.main_container.pack(expand=True, fill="both", padx=20, pady=20)
        
        # Show welcome screen first
        self.show_welcome_screen()
    
    def load_icons(self):
        """Load all required icons and logo as CTkImage"""
        self.icons = {}
        icon_files = {
            'investigator_name': "invname.png",
            'investigator_id': "invid.png",
            'case_name': "casename.png",
            'case_id': "caseid.png",
            'memory_id': "memoryid.png",
            'report_format': "report format.png",
            'hash': "hash.png"
        }
        
        # Load small icons (20x20)
        for key, filename in icon_files.items():
            icon_path = ICONS_DIR / filename
            if icon_path.exists():
                try:
                    img = Image.open(icon_path)
                    self.icons[key] = CTkImage(light_image=img, dark_image=img, size=(20, 20))
                except Exception as e:
                    print(f"Error loading {key} icon: {e}")

        # Load logo separately with larger size (200x200)
        logo_path = IMAGES_DIR / "bitmem_logo.png"
        if logo_path.exists():
            try:
                logo_img = Image.open(logo_path)
                self.icons['logo'] = CTkImage(light_image=logo_img, dark_image=logo_img, size=(200, 200))
            except Exception as e:
                print(f"Error loading logo: {e}")
    
    def clear_container(self):
        """Clear all widgets from the main container"""
        for widget in self.main_container.winfo_children():
            widget.destroy()
    
    def show_welcome_screen(self):
        """Welcome screen with BitMem logo and start button"""
        self.clear_container()
        
        container = ctk.CTkFrame(self.main_container, fg_color="transparent")
        container.pack(expand=True, fill="both", padx=40, pady=40)
        
        # Logo display - centered
        if 'logo' in self.icons:
            logo_frame = ctk.CTkFrame(container, fg_color="transparent")
            logo_frame.pack(pady=(0, 20))
            logo_label = ctk.CTkLabel(logo_frame, image=self.icons['logo'], text="")
            logo_label.pack()
        
        # Welcome text - bigger and centered
        welcome_frame = ctk.CTkFrame(container, fg_color="transparent")
        welcome_frame.pack(fill="x", pady=20)
        
        welcome_label = ctk.CTkLabel(
            welcome_frame,
            text="Welcome to BitMem",
            font=("Segoe UI", 32, "bold"),
            text_color=PRIMARY_COLOR
        )
        welcome_label.pack(pady=10)
        
        # Tagline
        tagline_label = ctk.CTkLabel(
            container,
            text="Professional Memory Acquisition Tool",
            font=("Segoe UI", 18),
            text_color=TEXT_COLOR
        )
        tagline_label.pack(pady=(0, 40))
        
        # Start button - centered with shadow effect
        btn_frame = ctk.CTkFrame(container, fg_color="transparent")
        btn_frame.pack()
        
        start_btn = ctk.CTkButton(
            btn_frame,
            text="Start Capture",
            font=("Segoe UI", 18, "bold"),
            fg_color=PRIMARY_COLOR,
            hover_color=ACCENT_COLOR,
            width=200,
            height=50,
            corner_radius=25,
            command=self.show_step1,
            border_width=2,
            border_color=ACCENT_COLOR
        )
        start_btn.pack(pady=20)
        
        # Footer note
        footer_label = ctk.CTkLabel(
            container,
            text="Thank you for choosing BitMem",
            font=("Segoe UI", 12, "italic"),
            text_color=SECONDARY_COLOR
        )
        footer_label.pack(pady=(40, 0))
        
        self.add_utility_buttons()
    
    def add_utility_buttons(self):
        """Add system info and mode switch buttons"""
        sys_info_btn = ctk.CTkButton(
            self.main_container, 
            text="ℹ",
            font=("Segoe UI", 16, "bold"),
            fg_color=PRIMARY_COLOR, 
            hover_color=ACCENT_COLOR,
            width=40,
            height=40,
            corner_radius=20,
            command=self.show_system_info
        )
        sys_info_btn.place(relx=0.05, rely=0.05, anchor="nw")
        
        self.mode_btn = ctk.CTkButton(
            self.main_container, 
            text="☀" if ctk.get_appearance_mode() == "Dark" else "🌙",
            font=("Segoe UI", 16, "bold"),
            fg_color=PRIMARY_COLOR, 
            hover_color=ACCENT_COLOR,
            width=40,
            height=40,
            corner_radius=20,
            command=self.toggle_mode
        )
        self.mode_btn.place(relx=0.95, rely=0.05, anchor="ne")
    
    def show_system_info(self):
        """Show system information"""
        ram = psutil.virtual_memory()
        cpu_usage = psutil.cpu_percent(interval=1)
        disk_usage = psutil.disk_usage('/')
        uptime = time.time() - psutil.boot_time()
        uptime_hours = int(uptime // 3600)
        uptime_minutes = int((uptime % 3600) // 60)
        
        info = (
            f"Total RAM: {ram.total / (1024 ** 3):.2f} GB\n"
            f"Used RAM: {ram.used / (1024 ** 3):.2f} GB\n"
            f"CPU Usage: {cpu_usage}%\n"
            f"Disk Usage: {disk_usage.percent}%\n"
            f"System Uptime: {uptime_hours}h {uptime_minutes}m"
        )
        messagebox.showinfo("System Information", info)
    
    def toggle_mode(self):
        """Toggle between dark/light mode"""
        global BACKGROUND_COLOR, PRIMARY_COLOR, SECONDARY_COLOR, ACCENT_COLOR, TEXT_COLOR
        current_mode = ctk.get_appearance_mode()
        if current_mode == "Dark":
            new_mode = "Light"
            BACKGROUND_COLOR = LIGHT_BACKGROUND
            PRIMARY_COLOR = LIGHT_PRIMARY
            SECONDARY_COLOR = LIGHT_SECONDARY
            ACCENT_COLOR = LIGHT_ACCENT
            TEXT_COLOR = LIGHT_TEXT
            self.mode_btn.configure(text="🌙")
        else:
            new_mode = "Dark"
            BACKGROUND_COLOR = DARK_BACKGROUND
            PRIMARY_COLOR = DARK_PRIMARY
            SECONDARY_COLOR = DARK_SECONDARY
            ACCENT_COLOR = DARK_ACCENT
            TEXT_COLOR = DARK_TEXT
            self.mode_btn.configure(text="☀")
        
        ctk.set_appearance_mode(new_mode)
        self.update_colors(new_mode)
        
        # Save preference to config
        config['appearance_mode'] = new_mode
        save_config(config)
    
    def update_colors(self, mode):
        """Update colors when theme changes"""
        self.main_container.configure(fg_color=BACKGROUND_COLOR)
        for widget in self.main_container.winfo_children():
            if isinstance(widget, ctk.CTkLabel):
                if "Step" in widget.cget("text"):
                    widget.configure(text_color=PRIMARY_COLOR)
                else:
                    widget.configure(text_color=TEXT_COLOR)
            elif isinstance(widget, ctk.CTkButton) and widget not in [self.mode_btn]:
                widget.configure(fg_color=PRIMARY_COLOR, hover_color=ACCENT_COLOR, text_color=TEXT_COLOR)
    
    def create_label_with_icon(self, parent, text, icon_key):
        """Create a label with an icon next to it"""
        frame = ctk.CTkFrame(parent, fg_color="transparent")
        
        if icon_key in self.icons:
            icon_label = ctk.CTkLabel(frame, image=self.icons[icon_key], text="")
            icon_label.pack(side="left", padx=(0, 5))
        
        label = ctk.CTkLabel(frame, text=text, font=("Segoe UI", 14), text_color=TEXT_COLOR)
        label.pack(side="left")
        
        return frame
    
    def show_step1(self):
        """Step 1: User information input"""
        self.clear_container()
        
        container = ctk.CTkFrame(self.main_container, fg_color="transparent")
        container.pack(expand=True, fill="both", padx=20, pady=20)
        
        title = ctk.CTkLabel(
            container,
            text="Step 1: Enter Case Details",
            font=("Segoe UI", 20, "bold"),
            text_color=PRIMARY_COLOR
        )
        title.pack(pady=20)
        
        input_frame = ctk.CTkFrame(container, corner_radius=10, fg_color=BACKGROUND_COLOR)
        input_frame.pack(pady=10, padx=20, fill="both", expand=True)
        
        input_frame.grid_columnconfigure(0, weight=1)
        input_frame.grid_columnconfigure(1, weight=1)

        # Investigator Details
        self.create_label_with_icon(input_frame, "Investigator Name:", "investigator_name").grid(row=0, column=0, padx=10, pady=10, sticky="e")
        self.investigator_name_entry = ctk.CTkEntry(input_frame, font=("Segoe UI", 14), fg_color=SECONDARY_COLOR, text_color=TEXT_COLOR)
        self.investigator_name_entry.grid(row=0, column=1, padx=10, pady=10, sticky="w")
        self.investigator_name_entry.insert(0, self.user_data.get("investigator_name", ""))

        self.create_label_with_icon(input_frame, "Investigator ID:", "investigator_id").grid(row=1, column=0, padx=10, pady=10, sticky="e")
        self.investigator_id_entry = ctk.CTkEntry(input_frame, font=("Segoe UI", 14), fg_color=SECONDARY_COLOR, text_color=TEXT_COLOR)
        self.investigator_id_entry.grid(row=1, column=1, padx=10, pady=10, sticky="w")
        self.investigator_id_entry.insert(0, self.user_data.get("investigator_id", ""))

        # Case Details
        self.create_label_with_icon(input_frame, "Case Name:", "case_name").grid(row=2, column=0, padx=10, pady=10, sticky="e")
        self.case_name_entry = ctk.CTkEntry(input_frame, font=("Segoe UI", 14), fg_color=SECONDARY_COLOR, text_color=TEXT_COLOR)
        self.case_name_entry.grid(row=2, column=1, padx=10, pady=10, sticky="w")
        self.case_name_entry.insert(0, self.user_data.get("case_name", ""))

        self.create_label_with_icon(input_frame, "Case ID:", "case_id").grid(row=3, column=0, padx=10, pady=10, sticky="e")
        self.case_id_entry = ctk.CTkEntry(input_frame, font=("Segoe UI", 14), fg_color=SECONDARY_COLOR, text_color=TEXT_COLOR)
        self.case_id_entry.grid(row=3, column=1, padx=10, pady=10, sticky="w")
        self.case_id_entry.insert(0, self.user_data.get("case_id", ""))

        # Memory ID
        self.create_label_with_icon(input_frame, "Memory ID:", "memory_id").grid(row=4, column=0, padx=10, pady=10, sticky="e")
        self.memory_id_entry = ctk.CTkEntry(input_frame, font=("Segoe UI", 14), fg_color=SECONDARY_COLOR, text_color=TEXT_COLOR)
        self.memory_id_entry.grid(row=4, column=1, padx=10, pady=10, sticky="w")
        self.memory_id_entry.insert(0, self.user_data.get("memory_id", ""))

        # Report Format
        self.create_label_with_icon(input_frame, "Report Format:", "report_format").grid(row=5, column=0, padx=10, pady=10, sticky="e")
        self.report_format_var = StringVar(value=self.user_data.get("report_format", "pdf"))
        report_format_menu = ctk.CTkOptionMenu(
            input_frame,
            variable=self.report_format_var,
            values=["txt", "pdf", "html", "docx", "json"],
            font=("Segoe UI", 14),
            fg_color=SECONDARY_COLOR,
            text_color=TEXT_COLOR
        )
        report_format_menu.grid(row=5, column=1, padx=10, pady=10, sticky="w")

        # Hash Algorithm
        self.create_label_with_icon(input_frame, "Hash Algorithm:", "hash").grid(row=6, column=0, padx=10, pady=10, sticky="e")
        self.hash_algorithm = StringVar(value=self.user_data.get("hash_algorithm", "sha256"))
        hash_menu = ctk.CTkOptionMenu(
            input_frame, 
            variable=self.hash_algorithm,
            values=["md5", "sha1", "sha256", "sha512"],
            font=("Segoe UI", 14),
            fg_color=SECONDARY_COLOR,
            text_color=TEXT_COLOR
        )
        hash_menu.grid(row=6, column=1, padx=10, pady=10, sticky="w")
        
        # Set up Enter key navigation
        entries = [
            self.investigator_name_entry,
            self.investigator_id_entry,
            self.case_name_entry,
            self.case_id_entry,
            self.memory_id_entry,
            report_format_menu,
            hash_menu
        ]
        
        for i, entry in enumerate(entries[:-1]):
            entry.bind('<Return>', lambda e, next_entry=entries[i+1]: next_entry.focus())
        
        # Navigation buttons
        button_frame = ctk.CTkFrame(container)
        button_frame.pack(pady=20)
        
        back_btn = ctk.CTkButton(
            button_frame,
            text="←",
            font=("Segoe UI", 18, "bold"),
            fg_color=PRIMARY_COLOR,
            hover_color=ACCENT_COLOR,
            width=60,
            height=60,
            corner_radius=30,
            command=self.show_welcome_screen
        )
        back_btn.pack(side="left", padx=10)
        
        next_btn = ctk.CTkButton(
            button_frame,
            text="→",
            font=("Segoe UI", 18, "bold"),
            fg_color=PRIMARY_COLOR,
            hover_color=ACCENT_COLOR,
            width=60,
            height=60,
            corner_radius=30,
            command=self.validate_step1
        )
        next_btn.pack(side="right", padx=10)
        
        # Focus first field
        self.investigator_name_entry.focus()
        
        self.add_utility_buttons()
    
    def validate_step1(self):
        """Validate step 1 inputs before proceeding"""
        if not all([
            self.investigator_name_entry.get(),
            self.investigator_id_entry.get(),
            self.case_name_entry.get(),
            self.case_id_entry.get(),
            self.memory_id_entry.get()
        ]):
            messagebox.showerror("Error", "Please fill all fields")
            return
        
        self.user_data = {
            "investigator_name": self.investigator_name_entry.get(),
            "investigator_id": self.investigator_id_entry.get(),
            "case_name": self.case_name_entry.get(),
            "case_id": self.case_id_entry.get(),
            "memory_id": self.memory_id_entry.get(),
            "report_format": self.report_format_var.get(),
            "hash_algorithm": self.hash_algorithm.get()
        }
        
        self.show_step2()
    
    def show_step2(self):
        """Step 2: File selection"""
        self.clear_container()
        
        container = ctk.CTkFrame(self.main_container, fg_color="transparent")
        container.pack(expand=True, fill="both", padx=20, pady=20)
        
        title = ctk.CTkLabel(
            container,
            text="Step 2: Select Output Location",
            font=("Segoe UI", 20, "bold"),
            text_color=PRIMARY_COLOR
        )
        title.pack(pady=20)
        
        info_frame = ctk.CTkFrame(container, corner_radius=10, fg_color=BACKGROUND_COLOR)
        info_frame.pack(pady=10, padx=20, fill="x")
        
        ctk.CTkLabel(
            info_frame, 
            text=f"Investigator: {self.user_data['investigator_name']} (ID: {self.user_data['investigator_id']})",
            font=("Segoe UI", 14),
            text_color=TEXT_COLOR
        ).pack(pady=5)
        
        ctk.CTkLabel(
            info_frame, 
            text=f"Case: {self.user_data['case_name']} (ID: {self.user_data['case_id']})",
            font=("Segoe UI", 14),
            text_color=TEXT_COLOR
        ).pack(pady=5)
        
        select_btn_frame = ctk.CTkFrame(container, fg_color="transparent")
        select_btn_frame.pack(pady=20)
        
        select_btn = ctk.CTkButton(
            select_btn_frame,
            text="📁 Select Output File",
            font=("Segoe UI", 14, "bold"),
            fg_color=PRIMARY_COLOR,
            hover_color=ACCENT_COLOR,
            command=self.select_file
        )
        select_btn.pack(pady=10)
        
        button_frame = ctk.CTkFrame(container)
        button_frame.pack(pady=20)
        
        back_btn = ctk.CTkButton(
            button_frame,
            text="←",
            font=("Segoe UI", 18, "bold"),
            fg_color=PRIMARY_COLOR,
            hover_color=ACCENT_COLOR,
            width=60,
            height=60,
            corner_radius=30,
            command=self.show_step1
        )
        back_btn.pack(side="left", padx=10)
        
        next_btn = ctk.CTkButton(
            button_frame,
            text="→",
            font=("Segoe UI", 18, "bold"),
            fg_color=PRIMARY_COLOR,
            hover_color=ACCENT_COLOR,
            width=60,
            height=60,
            corner_radius=30,
            command=self.select_file
        )
        next_btn.pack(side="right", padx=10)
        
        self.add_utility_buttons()
    
    def select_file(self):
        """File selection dialog"""
        self.output_file = filedialog.asksaveasfilename(
            title="Select location to save memory image",
            defaultextension=".raw",
            filetypes=[("RAW files", "*.raw"), ("All Files", "*.*")]
        )
        
        if not self.output_file:
            messagebox.showerror("Error", "No file selected. Please try again.")
            return
        
        self.show_step3()
    
    def show_step3(self):
        """Step 3: Capture with progress"""
        self.clear_container()
        
        container = ctk.CTkFrame(self.main_container, fg_color="transparent")
        container.pack(expand=True, fill="both", padx=20, pady=20)
        
        title = ctk.CTkLabel(
            container,
            text="Step 3: Capture Memory",
            font=("Segoe UI", 20, "bold"),
            text_color=PRIMARY_COLOR
        )
        title.pack(pady=20)
        
        info_frame = ctk.CTkFrame(container, corner_radius=10, fg_color=BACKGROUND_COLOR)
        info_frame.pack(pady=10, padx=20, fill="x")
        
        ctk.CTkLabel(
            info_frame, 
            text=f"Case: {self.user_data['case_name']}",
            font=("Segoe UI", 14),
            text_color=TEXT_COLOR
        ).pack(pady=5)
        
        ctk.CTkLabel(
            info_frame, 
            text=f"Output File: {self.output_file}",
            font=("Segoe UI", 14),
            text_color=TEXT_COLOR
        ).pack(pady=5)
        
        self.progress_bar = ctk.CTkProgressBar(
            container,
            mode="determinate",
            width=400,
            fg_color=SECONDARY_COLOR,
            progress_color=PRIMARY_COLOR
        )
        self.progress_bar.pack(pady=20)
        self.progress_bar.set(0)
        
        self.progress_label = ctk.CTkLabel(
            container,
            text="Ready to capture...",
            font=("Segoe UI", 14),
            text_color=TEXT_COLOR,
            fg_color=SECONDARY_COLOR
        )
        self.progress_label.pack(pady=10)
        
        self.time_left_label = ctk.CTkLabel(
            container,
            text="Estimated time remaining: --",
            font=("Segoe UI", 12),
            text_color=TEXT_COLOR,
            fg_color=SECONDARY_COLOR
        )
        self.time_left_label.pack(pady=5)
        
        self.system_stats_label = ctk.CTkLabel(
            container,
            text="CPU: --% | RAM: --%",
            font=("Segoe UI", 12),
            text_color=TEXT_COLOR,
            fg_color=SECONDARY_COLOR
        )
        self.system_stats_label.pack(pady=5)
        
        button_frame = ctk.CTkFrame(container)
        button_frame.pack(pady=20)
        
        back_btn = ctk.CTkButton(
            button_frame,
            text="←",
            font=("Segoe UI", 18, "bold"),
            fg_color=PRIMARY_COLOR,
            hover_color=ACCENT_COLOR,
            width=60,
            height=60,
            corner_radius=30,
            command=self.show_step2
        )
        back_btn.pack(side="left", padx=10)
        
        self.capture_btn = ctk.CTkButton(
            button_frame,
            text="⚡",
            font=("Segoe UI", 18, "bold"),
            fg_color=PRIMARY_COLOR,
            hover_color=ACCENT_COLOR,
            width=60,
            height=60,
            corner_radius=30,
            command=self.start_capture
        )
        self.capture_btn.pack(side="right", padx=10)
        
        self.add_utility_buttons()
    
    def start_capture(self):
        """Start or resume capture"""
        if self.resume_capture and self.partial_capture_path:
            resume_msg = f"Resume previous capture?\nPartial file: {os.path.getsize(self.partial_capture_path)/1024/1024:.2f} MB"
            if messagebox.askyesno("Resume Capture", resume_msg):
                self.output_file = self.partial_capture_path
                self.capture_bytes_copied = os.path.getsize(self.output_file)
            else:
                self.resume_capture = False
                self.partial_capture_path = None
        
        if not self.resume_capture:
            self.capture_bytes_copied = 0
            self.capture_start_time = time.time()
            self.total_memory_size = psutil.virtual_memory().total
        
        try:
            investigator_id = int(self.user_data["investigator_id"])
            case_id = int(self.user_data["case_id"])
            memory_id = int(self.user_data["memory_id"])
        except ValueError:
            messagebox.showerror("Error", "IDs must be integers.")
            return
        
        errors = validate_unique_ids(investigator_id, case_id, memory_id)
        if errors:
            messagebox.showerror("Error", "\n".join(errors))
            return
        
        winpmem_path = BASE_DIR / "winpmem_mini.exe"
        
        if not winpmem_path.exists():
            messagebox.showerror("Error", "winpmem_mini.exe not found.")
            return
        
        self.capture_active = True
        self.capture_btn.configure(text="■", command=self.stop_capture)
        self.progress_label.configure(text="Initializing capture...")
        
        self.capture_thread = threading.Thread(
            target=self.run_capture_process,
            args=(str(winpmem_path), self.output_file),
            daemon=True
        )
        self.capture_thread.start()
    
    def run_capture_process(self, winpmem_path, output_file):
        """Run the actual capture process"""
        command = [winpmem_path, output_file]
        start_time = time.time()
        
        mem_info = psutil.virtual_memory()
        self.total_memory_size = mem_info.total
        self.capture_start_time = start_time
        
        try:
            self.capture_process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
            
            while self.capture_active:
                current_size = os.path.getsize(output_file) if os.path.exists(output_file) else 0
                progress = min((self.capture_bytes_copied + current_size) / self.total_memory_size, 0.99)
                
                elapsed = time.time() - start_time
                if progress > 0.01 and elapsed > 0:
                    estimated_total = elapsed / progress
                    remaining = max(estimated_total - elapsed, 0)
                    self.time_left_label.configure(text=f"Time left: {remaining:.1f} seconds")
                
                cpu_percent = psutil.cpu_percent()
                mem_percent = psutil.virtual_memory().percent
                self.system_stats_label.configure(text=f"CPU: {cpu_percent}% | RAM: {mem_percent}%")
                
                transfer_rate = current_size / (1024 * 1024 * elapsed) if elapsed > 0 else 0
                self.progress_label.configure(
                    text=f"Capturing... {progress*100:.1f}% | Speed: {transfer_rate:.1f} MB/s"
                )
                
                self.progress_bar.set(progress)
                self.root.update_idletasks()
                time.sleep(0.5)
            
            if not self.capture_active:
                self.capture_process.terminate()
                self.root.after(0, lambda: self.finish_capture(stopped=True))
                return
            
            if not os.path.exists(output_file):
                self.root.after(0, lambda: self.progress_label.configure(text="Capture failed!"))
                self.root.after(0, lambda: messagebox.showerror("Error", "Memory image file was not created."))
                return
            
            hash_value = calculate_hash(output_file, self.user_data["hash_algorithm"])
            image_size = os.path.getsize(output_file)
            elapsed_time = time.time() - start_time
            
            report_file = generate_report(
                output_file,
                self.user_data["investigator_name"],
                investigator_id,
                self.user_data["case_name"],
                case_id,
                memory_id,
                hash_value,
                image_size,
                elapsed_time,
                self.user_data["report_format"],
                self.user_data["hash_algorithm"]
            )
            
            used_investigator_ids.add(investigator_id)
            used_case_ids.add(case_id)
            used_memory_ids.add(memory_id)
            
            self.root.after(0, lambda: self.finish_capture(
                success=True,
                output_file=output_file,
                report_file=report_file
            ))
            
        except Exception as e:
            self.root.after(0, lambda: self.progress_label.configure(text=f"Error: {str(e)}"))
            self.root.after(0, lambda: messagebox.showerror("Error", f"An exception occurred: {str(e)}"))
        finally:
            self.capture_active = False
            self.capture_process = None
    
    def stop_capture(self):
        """Stop capture and save partial progress"""
        self.capture_active = False
        if self.capture_process:
            self.capture_process.terminate()
        
        if os.path.exists(self.output_file):
            file_size = os.path.getsize(self.output_file)
            if file_size > 0 and file_size < self.total_memory_size:
                if messagebox.askyesno("Partial Capture", "Save partial capture for resuming later?"):
                    self.partial_capture_path = self.output_file
                    self.resume_capture = True
                    self.capture_bytes_copied = file_size
    
    def finish_capture(self, stopped=False, success=False, output_file="", report_file=""):
        """Clean up after capture completes or is stopped"""
        self.capture_active = False
        self.capture_btn.configure(
            text="⚡",
            command=self.start_capture,
            state="normal"
        )
        
        if stopped:
            self.progress_label.configure(text="Capture stopped")
            messagebox.showinfo("Stopped", "Capture process was stopped")
        elif success:
            self.progress_label.configure(text="Capture complete!")
            messagebox.showinfo(
                "Success", 
                f"RAM image captured successfully!\nSaved at: {output_file}\nReport saved at: {report_file}"
            )
            self.resume_capture = False
            self.partial_capture_path = None
        else:
            self.progress_label.configure(text="Capture failed!")
            self.time_left_label.configure(text="")
            self.system_stats_label.configure(text="")

def create_gui():
    root = ctk.CTk()
    app = MemoryCaptureApp(root)
    root.mainloop()

if __name__ == "__main__":
    create_gui()